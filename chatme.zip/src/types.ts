/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  fullname: string;
  email: string;
  password?: string; // Stored securely in client simulated database
  photo: string; // Base64 or avatar URL
  bio: string;
  phone: string;
  created_at: string;
  isOnline?: boolean;
}

export interface GroupChat {
  id: string;
  name: string;
  members: string[]; // User IDs
  created_at: string;
  photo?: string;
}

export interface ChatMessage {
  id: string;
  sender_id: string;
  receiver_id: string; // Can be a User ID or GroupChat ID
  is_group?: boolean;
  message: string;
  image?: string; // base64 URL of sent image
  file?: {
    name: string;
    size: string;
    type: string;
    url?: string;
  };
  timestamp: string; // ISO string
  status: 'sent' | 'delivered' | 'read';
}

export interface Contact {
  id: string;
  user_id: string;
  contact_id: string;
}

export interface CallRecord {
  id: string;
  caller_id: string;
  receiver_id: string;
  type: 'voice' | 'video';
  duration: string; // e.g., "00:45" or "Missed"
  timestamp: string; // ISO string
  status: 'incoming' | 'outgoing' | 'missed';
}

export type ScreenType =
  | 'splash'
  | 'signin'
  | 'signup'
  | 'resetpassword'
  | 'home' // Bottom nav shows Chats, Contacts, Calls, Profile
  | 'chat' // Active messaging with a contact
  | 'settings';

export type HomeTab = 'chats' | 'status' | 'contacts' | 'calls' | 'chatbot' | 'profile';

export interface ActiveCallState {
  contact: User;
  type: 'voice' | 'video';
  status: 'dialing' | 'connected' | 'ended';
  durationSeconds: number;
}

export interface AppSettings {
  darkMode: boolean;
  notificationsEnabled: boolean;
  privacyLocked: boolean;
}

export interface StatusPost {
  id: string;
  user_id: string;
  type: 'text' | 'image' | 'video';
  content?: string; // For text
  media_url?: string; // For image/video
  caption?: string;
  background_color?: string; // For text status
  created_at: string;
  expires_at: string;
}

export interface StatusView {
  id: string;
  status_id: string;
  viewer_id: string;
  viewed_at: string;
}

export interface StatusReaction {
  id: string;
  status_id: string;
  reactor_id: string;
  emoji: string;
  created_at: string;
}
