/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, MessageSquare, Check, CheckCheck, Bot } from 'lucide-react';
import { User, ChatMessage } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface ChatsTabProps {
  currentUser: User;
  onOpenChat: (contact: User) => void;
  darkMode: boolean;
  onOpenAI: () => void; // Add this prop
}

export default function ChatsTab({ currentUser, onOpenChat, darkMode, onOpenAI }: ChatsTabProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  // 1. Get All chats for active user
  const chats = ChatMeDB.getChatsForUser(currentUser.id);
  const users = ChatMeDB.getUsers().filter((u) => u.id !== currentUser.id);

  // 2. Gather conversation aggregates (group chats by contact ID)
  const conversationMap: Record<string, { lastMessage: ChatMessage; unreadCount: number }> = {};

  chats.forEach((msg) => {
    const contactId = msg.sender_id === currentUser.id ? msg.receiver_id : msg.sender_id;
    
    // Increment unread count if message came from contact and is not read
    const isUnread = msg.sender_id !== currentUser.id && msg.status !== 'read';

    if (!conversationMap[contactId]) {
      conversationMap[contactId] = { lastMessage: msg, unreadCount: isUnread ? 1 : 0 };
    } else {
      const existing = conversationMap[contactId];
      if (isUnread) {
        existing.unreadCount += 1;
      }
      // Update last message if current is newer
      if (new Date(msg.timestamp) > new Date(existing.lastMessage.timestamp)) {
        existing.lastMessage = msg;
      }
    }
  });

  // 3. Map contacts with their last active conversation details
  const activeChatsList = users
    .map((contact) => {
      const convo = conversationMap[contact.id];
      return {
        contact,
        lastMessage: convo?.lastMessage || null,
        unreadCount: convo?.unreadCount || 0,
      };
    })
    // Sort so that chats with messages appear first, sorted by newest message timestamp
    .sort((a, b) => {
      if (!a.lastMessage && !b.lastMessage) return 0;
      if (!a.lastMessage) return 1;
      if (!b.lastMessage) return -1;
      return new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime();
    })
    // Filter by search query
    .filter((item) =>
      item.contact.fullname.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.lastMessage?.message || '').toLowerCase().includes(searchQuery.toLowerCase())
    );

  // Format timestamp helper
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      
      const diffMs = now.getTime() - date.getTime();
      const diffDays = Math.floor(diffMs / (24 * 3600 * 1000));

      if (diffDays === 0) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } else if (diffDays === 1) {
        return 'Yesterday';
      } else if (diffDays < 7) {
        return date.toLocaleDateString([], { weekday: 'short' });
      } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
      }
    } catch {
      return '';
    }
  };

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden select-none transition-all duration-300 relative ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Header bar */}
      <div className={`pt-2 pb-4 px-6 flex justify-between items-center transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <h2 className="text-2xl font-bold font-display tracking-tight flex items-center gap-2">
          Chat<span className="text-brand-primary">Me</span>
        </h2>
        
        <button
          onClick={() => setShowSearch(!showSearch)}
          className={`p-2 rounded-xl transition-colors ${
            darkMode 
              ? 'text-zinc-400 hover:text-white hover:bg-zinc-800/40' 
              : 'text-zinc-500 hover:text-zinc-900 hover:bg-white/40'
          }`}
        >
          <Search size={20} />
        </button>
      </div>

      {/* Slide down Search Bar */}
      {showSearch && (
        <div className={`px-4 py-2 border-b transition-all duration-300 ${
          darkMode ? 'bg-zinc-900/35 border-zinc-800/30' : 'bg-white/35 border-white/30'
        }`}>
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="text"
              placeholder="Search chat thread or text..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full h-9 pl-9 pr-4 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
                darkMode
                  ? 'bg-zinc-900/30 focus:bg-zinc-900/50 border border-zinc-800/40 text-white placeholder-zinc-500'
                  : 'bg-white/50 focus:bg-white/70 border border-white/55 text-zinc-800 placeholder-zinc-400'
              }`}
              autoFocus
            />
          </div>
        </div>
      )}

      {/* Chats Threads List */}
      <div className="flex-1 overflow-y-auto bg-transparent">
        {activeChatsList.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-80 px-8 text-center">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-colors ${
              darkMode ? 'bg-zinc-850 text-zinc-700' : 'bg-slate-50 text-slate-300'
            }`}>
              <MessageSquare size={28} />
            </div>
            <p className="text-sm font-semibold text-zinc-400">No chats found</p>
            <p className="text-xs text-zinc-500 mt-1">Try starting a chat from your Contacts screen!</p>
          </div>
        ) : (
          <div className="divide-y divide-white/10 dark:divide-zinc-800/25">
            {activeChatsList.map(({ contact, lastMessage, unreadCount }) => (
              <div
                key={contact.id}
                onClick={() => onOpenChat(contact)}
                className={`flex items-center gap-4 py-3.5 px-6 cursor-pointer transition-all duration-200 ${
                  darkMode 
                    ? 'hover:bg-zinc-800/35' 
                    : 'hover:bg-white/35'
                }`}
              >
                {/* Profile Pic with Online Ring Indicator */}
                <div className="relative shrink-0">
                  <div
                    style={getAvatarStyle(contact.photo)}
                    className="w-12 h-12 rounded-[14px] border-2 border-transparent shadow-sm flex items-center justify-center text-white font-bold font-display"
                  >
                    {contact.photo.startsWith('gradient:') && getInitials(contact.fullname)}
                  </div>
                  {/* Online dot */}
                  {contact.isOnline && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-brand-primary border-2 border-white dark:border-zinc-900 rounded-full shadow-sm" />
                  )}
                </div>

                {/* Info Text block */}
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <h4 className={`text-[14px] font-bold truncate tracking-tight ${
                      darkMode ? 'text-zinc-100' : 'text-zinc-850'
                    }`}>
                      {contact.fullname}
                    </h4>
                    <span className="text-[10px] font-semibold text-zinc-400 shrink-0">
                      {lastMessage ? formatTime(lastMessage.timestamp) : ''}
                    </span>
                  </div>

                  <div className="flex justify-between items-center gap-2">
                    {/* Last Message line */}
                    <p className={`text-xs truncate flex-1 ${
                      unreadCount > 0 
                        ? (darkMode ? 'text-white font-semibold' : 'text-zinc-900 font-semibold')
                        : 'text-zinc-500 font-medium'
                    }`}>
                      {lastMessage ? (
                        lastMessage.image ? (
                          <span className="text-brand-secondary font-semibold">📸 Sent an image</span>
                        ) : lastMessage.file ? (
                          <span className="text-brand-secondary font-semibold">📎 Sent: {lastMessage.file.name}</span>
                        ) : (
                          lastMessage.message
                        )
                      ) : (
                        <span className="text-zinc-400 italic">No messages yet</span>
                      )}
                    </p>

                    {/* Unread badge & double ticks */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Read receipts */}
                      {lastMessage && lastMessage.sender_id === currentUser.id && (
                        <span>
                          {lastMessage.status === 'read' ? (
                            <CheckCheck size={14} className="text-brand-primary" />
                          ) : lastMessage.status === 'delivered' ? (
                            <CheckCheck size={14} className="text-zinc-400" />
                          ) : (
                            <Check size={14} className="text-zinc-400" />
                          )}
                        </span>
                      )}

                      {/* Unread Circle Badge */}
                      {unreadCount > 0 && (
                        <span className="h-5 min-w-5 px-1.5 rounded-full bg-brand-primary text-white text-[10px] font-extrabold flex items-center justify-center shadow-md shadow-emerald-500/10">
                          {unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Floating AI Action Button */}
      <button
        onClick={onOpenAI}
        className="absolute bottom-6 right-6 p-4 bg-brand-primary text-white rounded-full shadow-lg hover:scale-105 transition-transform"
      >
        <Bot size={24} />
      </button>

    </div>
  );
}
