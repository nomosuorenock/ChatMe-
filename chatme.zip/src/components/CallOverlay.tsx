/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Volume2, VolumeX, Camera } from 'lucide-react';
import { User, ActiveCallState } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface CallOverlayProps {
  callState: ActiveCallState;
  onEndCall: (durationStr: string) => void;
  currentUser: User;
  darkMode: boolean;
}

export default function CallOverlay({ callState, onEndCall, currentUser, darkMode }: CallOverlayProps) {
  const { contact, type } = callState;
  
  const [status, setStatus] = useState<'dialing' | 'connected' | 'ended'>(callState.status);
  const [seconds, setSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(type === 'video');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const ringOscillatorRef = useRef<OscillatorNode | null>(null);

  // 1. Synthesize Ringing Sound (Web Audio API)
  const startRingingSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      // Create a nice double frequency digital ringtone (440Hz + 480Hz)
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc1.frequency.value = 440;
      osc2.frequency.value = 480;
      gainNode.gain.value = 0; // start silent

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc1.start();
      osc2.start();

      // Looping ring cycle: 1.5 seconds play, 2 seconds silence
      let active = true;
      const playRing = () => {
        if (!active || ctx.state === 'closed') return;
        gainNode.gain.setValueAtTime(0.12, ctx.currentTime);
        gainNode.gain.setValueAtTime(0, ctx.currentTime + 1.2);
      };

      playRing();
      const interval = setInterval(playRing, 3500);

      ringOscillatorRef.current = osc1; // Hold reference to stop later
      (ringOscillatorRef as any).current._interval = interval;
      (ringOscillatorRef as any).current._gainNode = gainNode;
    } catch (e) {
      console.warn('Web Audio Context ringtone failed to start:', e);
    }
  };

  const stopRingingSound = () => {
    try {
      if (ringOscillatorRef.current) {
        clearInterval((ringOscillatorRef as any).current._interval);
        if ((ringOscillatorRef as any).current._gainNode) {
          (ringOscillatorRef as any).current._gainNode.gain.setValueAtTime(0, audioContextRef.current?.currentTime || 0);
        }
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    } catch {}
  };

  // 2. Start User Video Stream for mock calling
  const startUserVideo = async () => {
    if (type === 'video' && isVideoOn) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: 200, height: 200 },
          audio: false, // Don't loop back micro feed
        });
        setCameraStream(stream);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn('Webcam feed could not be initialized:', err);
      }
    }
  };

  const stopUserVideo = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  };

  // 3. Orchestrate State Cycles
  useEffect(() => {
    // Start Ringing
    startRingingSound();
    
    // Auto-answer after 3 seconds
    const answerTimer = setTimeout(() => {
      stopRingingSound();
      setStatus('connected');
      startUserVideo();
    }, 3000);

    return () => {
      clearTimeout(answerTimer);
      stopRingingSound();
      stopUserVideo();
    };
  }, []);

  // 4. Track connected timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (status === 'connected') {
      timer = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [status]);

  // Video Toggle Action
  const toggleVideo = () => {
    if (isVideoOn) {
      stopUserVideo();
      setIsVideoOn(false);
    } else {
      setIsVideoOn(true);
      setTimeout(() => {
        startUserVideo();
      }, 100);
    }
  };

  // Hangup Click Action
  const handleHangUp = () => {
    stopRingingSound();
    stopUserVideo();
    setStatus('ended');
    
    // Save record of call
    const durationStr = seconds > 0 ? formatDuration(seconds) : 'Missed';
    
    // Trigger callback
    setTimeout(() => {
      onEndCall(durationStr);
    }, 600);
  };

  // Format second timer to 00:00
  const formatDuration = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60).toString().padStart(2, '0');
    const secs = (totalSecs % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  return (
    <div className="absolute inset-0 bg-zinc-950 text-white z-50 flex flex-col justify-between p-6 select-none">
      
      {/* Top Details Header */}
      <div className="flex flex-col items-center mt-12 text-center">
        {/* Call Type Indicator */}
        <span className="text-[11px] uppercase tracking-widest text-zinc-400 font-extrabold flex items-center gap-1.5 mb-2">
          {type === 'video' ? <Video size={12} className="text-brand-primary" /> : <Volume2 size={12} className="text-brand-primary" />}
          {type === 'video' ? 'Video Call' : 'Voice Call'}
        </span>

        {/* Username */}
        <h3 className="text-2xl font-bold tracking-tight">{contact.fullname}</h3>

        {/* Ringing/Duration Status */}
        <span className="text-sm font-medium text-brand-primary tracking-wide mt-1 animate-pulse">
          {status === 'dialing' ? 'Dialing...' : formatDuration(seconds)}
        </span>
      </div>

      {/* CENTER VIDEO OR WAVE AREA */}
      <div className="flex-1 my-8 flex items-center justify-center relative">
        {type === 'video' && status === 'connected' ? (
          /* VIDEO CALL VIEW */
          <div className="w-full h-full max-h-[420px] rounded-[32px] overflow-hidden bg-zinc-900 border border-zinc-800 relative flex items-center justify-center">
            
            {/* Main view (Pre-seeded contact photo backdrop) */}
            <div style={getAvatarStyle(contact.photo)} className="w-full h-full opacity-40 blur-md absolute inset-0" />
            
            {/* Floating high contrast contact display */}
            <div className="flex flex-col items-center z-15 gap-4">
              <div style={getAvatarStyle(contact.photo)} className="w-24 h-24 rounded-3xl border-2 border-brand-primary shadow-xl flex items-center justify-center">
                {contact.photo.startsWith('gradient:') && (
                  <span className="text-2xl font-bold font-display">{getInitials(contact.fullname)}</span>
                )}
              </div>
              <p className="text-xs text-zinc-300 font-medium tracking-wide">Connecting active video feeds...</p>
            </div>

            {/* PIP Live Webcam Window (rendered if permitted) */}
            {isVideoOn && (
              <div className="absolute bottom-4 right-4 w-28 h-36 rounded-2xl overflow-hidden bg-black border-2 border-brand-secondary z-30 shadow-2xl flex items-center justify-center">
                {cameraStream ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover scale-x-[-1]"
                  />
                ) : (
                  <div className="flex flex-col items-center gap-1">
                    <Camera size={18} className="text-zinc-500 animate-pulse" />
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider">Your Camera</span>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          /* VOICE CALL VIEW */
          <div className="relative flex flex-col items-center justify-center">
            
            {/* Big pulsating circle avatar wrapper */}
            <div className="relative flex items-center justify-center">
              <div className="absolute w-44 h-44 rounded-full bg-brand-primary/10 ring-pulsing" />
              <div className="absolute w-36 h-36 rounded-full bg-brand-primary/25" />
              
              <div
                style={getAvatarStyle(contact.photo)}
                className="w-28 h-28 rounded-full border-4 border-zinc-850 shadow-2xl z-10 flex items-center justify-center text-white"
              >
                {contact.photo.startsWith('gradient:') && (
                  <span className="text-3xl font-extrabold font-display">{getInitials(contact.fullname)}</span>
                )}
              </div>
            </div>

            {/* Dynamic pulsating frequency waves (only shown when connected) */}
            {status === 'connected' && (
              <div className="flex items-end justify-center gap-1.5 h-10 mt-12">
                <div className="w-1 bg-brand-primary rounded-full wave-bar" style={{ height: '70%', animationDelay: '0.1s' }} />
                <div className="w-1 bg-brand-secondary rounded-full wave-bar" style={{ height: '40%', animationDelay: '0.3s' }} />
                <div className="w-1 bg-brand-primary rounded-full wave-bar" style={{ height: '90%', animationDelay: '0.5s' }} />
                <div className="w-1 bg-brand-secondary rounded-full wave-bar" style={{ height: '50%', animationDelay: '0.2s' }} />
                <div className="w-1 bg-brand-primary rounded-full wave-bar" style={{ height: '75%', animationDelay: '0.4s' }} />
              </div>
            )}
          </div>
        )}
      </div>

      {/* BOTTOM CONTROL ACTIONS BUTTONS */}
      <div className="flex flex-col items-center gap-6 mb-8">
        
        {/* Toggle Controls row */}
        <div className="flex items-center gap-6">
          {/* Mute Button */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors border ${
              isMuted
                ? 'bg-red-500/20 border-red-500/50 text-red-400'
                : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
          </button>

          {/* Toggle Video Camera Button */}
          <button
            onClick={toggleVideo}
            disabled={type === 'voice' && status !== 'connected'}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors border ${
              type === 'voice'
                ? 'opacity-40 cursor-not-allowed bg-zinc-950 border-zinc-900 text-zinc-600'
                : isVideoOn
                ? 'bg-brand-secondary/20 border-brand-secondary/50 text-brand-secondary'
                : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            {isVideoOn ? <Video size={20} /> : <VideoOff size={20} />}
          </button>

          {/* Speaker Button */}
          <button
            onClick={() => setIsSpeakerOn(!isSpeakerOn)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors border ${
              !isSpeakerOn
                ? 'bg-zinc-950 border-zinc-900 text-zinc-500'
                : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            {isSpeakerOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
        </div>

        {/* Big Red End Call Action */}
        <button
          onClick={handleHangUp}
          className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 transition-colors flex items-center justify-center shadow-lg shadow-red-500/20 active:scale-95 text-white cursor-pointer"
        >
          <PhoneOff size={28} />
        </button>
      </div>

    </div>
  );
}
