/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Phone, Video, ArrowDownLeft, ArrowUpRight, PhoneMissed, PhoneCall } from 'lucide-react';
import { User, CallRecord } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface CallsTabProps {
  currentUser: User;
  onInitiateCall: (contact: User, type: 'voice' | 'video') => void;
  darkMode: boolean;
}

export default function CallsTab({ currentUser, onInitiateCall, darkMode }: CallsTabProps) {
  // 1. Get call records for this user
  const callRecords = ChatMeDB.getCalls(currentUser.id);
  const users = ChatMeDB.getUsers();

  // Sort calls newest first
  const sortedCalls = [...callRecords].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  // Time Formatter helper
  const formatCallTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (60 * 1000));
      const diffHours = Math.floor(diffMs / (3600 * 1000));

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden select-none transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Top Header */}
      <div className={`pt-2 pb-4 px-6 flex justify-between items-center transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <h2 className="text-2xl font-bold font-display tracking-tight">Call Logs</h2>
        <span className="text-[11px] font-bold bg-brand-secondary/10 text-brand-secondary px-2.5 py-1 rounded-full font-sans">
          {sortedCalls.length} Logs
        </span>
      </div>

      {/* Call History list view */}
      <div className="flex-1 overflow-y-auto bg-transparent">
        {sortedCalls.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-80 px-8 text-center">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-colors ${
              darkMode ? 'bg-zinc-800/45 text-zinc-650' : 'bg-white/45 text-slate-300'
            }`}>
              <PhoneCall size={28} />
            </div>
            <p className="text-sm font-semibold text-zinc-400">No calls registered yet</p>
            <p className="text-xs text-zinc-500 mt-1">Initiate voice/video calls inside active chat views!</p>
          </div>
        ) : (
          <div className="divide-y divide-white/10 dark:divide-zinc-800/25">
            {sortedCalls.map((call) => {
              // Peer is whoever is not the current user in this call
              const peerId = call.caller_id === currentUser.id ? call.receiver_id : call.caller_id;
              const peer = users.find((u) => u.id === peerId);

              if (!peer) return null;

              // Outgoing is when caller === current user
              const isOutgoing = call.caller_id === currentUser.id;
              const isMissed = call.status === 'missed';

              return (
                <div
                  key={call.id}
                  className="flex items-center justify-between py-3.5 px-6 hover:bg-white/35 dark:hover:bg-zinc-800/35 transition-all"
                >
                  {/* Left avatar details block */}
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div
                      style={getAvatarStyle(peer.photo)}
                      className="w-11 h-11 rounded-[12px] flex items-center justify-center text-white font-bold font-display text-sm border border-transparent shrink-0 shadow-sm"
                    >
                      {peer.photo.startsWith('gradient:') && getInitials(peer.fullname)}
                    </div>

                    {/* Peer name + directional arrow indicators */}
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-[13px] font-bold truncate tracking-tight ${
                        darkMode ? 'text-zinc-100' : 'text-zinc-850'
                      }`}>
                        {peer.fullname}
                      </h4>
                      
                      <div className="flex items-center gap-1.5 mt-1">
                        {/* Status Icon */}
                        {isMissed ? (
                          <PhoneMissed size={12} className="text-red-500 shrink-0" />
                        ) : isOutgoing ? (
                          <ArrowUpRight size={12} className="text-brand-primary shrink-0" />
                        ) : (
                          <ArrowDownLeft size={12} className="text-brand-secondary shrink-0" />
                        )}

                        {/* Call description text */}
                        <span className="text-[10px] font-semibold text-zinc-400">
                          {isMissed 
                            ? 'Missed call' 
                            : isOutgoing 
                            ? `Outgoing voice (${call.duration})` 
                            : `Incoming call (${call.duration})`}
                        </span>
                        
                        <span className="text-[10px] text-zinc-300 dark:text-zinc-700">•</span>
                        
                        {/* Time label */}
                        <span className="text-[10px] font-semibold text-zinc-400">
                          {formatCallTime(call.timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quick-Dial Call Action button */}
                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <button
                      onClick={() => onInitiateCall(peer, call.type)}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                        call.type === 'video'
                          ? 'bg-blue-50 hover:bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:hover:bg-blue-900/30'
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/30'
                      }`}
                    >
                      {call.type === 'video' ? <Video size={16} /> : <Phone size={16} />}
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
