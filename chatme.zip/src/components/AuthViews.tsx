/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { MessageSquareDot, Mail, Lock, User as UserIcon, Phone, Upload, Eye, EyeOff, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { ChatMeDB, getAvatarStyle } from '../lib/database';
import { getSupabase } from '../lib/supabaseClient';
import { User } from '../types';

interface AuthViewsProps {
  currentScreen: 'signin' | 'signup' | 'resetpassword';
  onNavigate: (screen: 'signin' | 'signup' | 'resetpassword' | 'home') => void;
  onLoginSuccess: (user: User) => void;
  darkMode: boolean;
}

export default function AuthViews({ currentScreen, onNavigate, onLoginSuccess, darkMode }: AuthViewsProps) {
  // Input fields
  const [fullname, setFullname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [bio, setBio] = useState('');
  const [photo, setPhoto] = useState<string>('gradient:from-emerald-400:to-teal-600');

  // UI States
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File to base64 converter
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrorMsg('Photo must be smaller than 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
        setErrorMsg('');
      };
      reader.readAsDataURL(file);
    }
  };

  // Sign In submit
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      if (!email.trim() || !password.trim()) {
        setErrorMsg('Please fill in all fields');
        setLoading(false);
        return;
      }

      const { data, error } = await getSupabase().auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Supabase user maps to our User type
      const user: User = {
        id: data.user.id,
        fullname: data.user.user_metadata.fullname || 'User',
        email: data.user.email || '',
        photo: data.user.user_metadata.photo || 'gradient:from-emerald-400:to-teal-600',
        bio: data.user.user_metadata.bio || '',
        phone: data.user.user_metadata.phone || '',
        password: '', // Should not be stored or needed
        isOnline: true,
        created_at: data.user.created_at || new Date().toISOString()
      };
      
      onLoginSuccess(user);
      onNavigate('home');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sign in');
    } finally {
      setLoading(false);
    }
  };

  // Sign Up submit
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      // Validations (Keep existing validation logic)
      if (!fullname.trim() || !email.trim() || !password.trim() || !confirmPassword.trim()) {
        throw new Error('All fields are required');
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        throw new Error('Please enter a valid email address');
      }

      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters');
      }

      if (password !== confirmPassword) {
        throw new Error('Passwords do not match');
      }

      const { data, error } = await getSupabase().auth.signUp({
        email,
        password,
        options: {
          data: {
            fullname,
            photo,
            bio: bio.trim() || 'Excited to be on ChatMe! 👋',
            phone: phone.trim() || '+1 (555) 000-0000',
          }
        }
      });

      if (error) throw error;
      if (!data.user) throw new Error('Failed to create account');

      const user: User = {
        id: data.user.id,
        fullname,
        email: data.user.email || '',
        photo,
        bio: bio.trim() || 'Excited to be on ChatMe! 👋',
        phone: phone.trim() || '+1 (555) 000-0000',
        password: '',
        isOnline: true,
        created_at: new Date().toISOString()
      };

      onLoginSuccess(user);
      onNavigate('home');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sign up');
    } finally {
      setLoading(false);
    }
  };

  // Reset password submit
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      if (!email.trim()) {
        throw new Error('Email address is required');
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        throw new Error('Please enter a valid email address');
      }

      const { error } = await getSupabase().auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/update-password`,
      });

      if (error) throw error;

      setSuccessMsg('Reset instructions have been sent to your email.');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send reset instructions');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`w-full h-full flex flex-col justify-start overflow-y-auto px-6 py-8 transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Brand Logo Header */}
      <div className="flex flex-col items-center mt-4 mb-6">
        <div className="relative w-12 h-12 rounded-xl bg-gradient-to-tr from-brand-primary to-brand-secondary flex items-center justify-center shadow-lg shadow-emerald-500/10 mb-2">
          <MessageSquareDot size={26} className="text-white" />
        </div>
        <span className="text-xl font-extrabold font-display tracking-tight">
          Chat<span className="text-brand-primary">Me</span>
        </span>
      </div>

      {/* ERROR / SUCCESS ALERTS */}
      {errorMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 mb-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 flex items-start gap-2.5 text-red-600 dark:text-red-400 text-xs font-medium"
        >
          <AlertCircle size={16} className="shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </motion.div>
      )}

      {successMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 mb-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 flex items-start gap-2.5 text-emerald-600 dark:text-emerald-400 text-xs font-medium"
        >
          <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
          <span>{successMsg}</span>
        </motion.div>
      )}

      {/* ==================== SIGN IN SCREEN ==================== */}
      {currentScreen === 'signin' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 20 }}
          className="flex flex-col flex-1"
        >
          <div className="mb-6">
            <h2 className="text-2xl font-bold tracking-tight">Welcome Back</h2>
            <p className="text-xs text-zinc-500 mt-1">Sign in to continue chatting</p>
          </div>

          <form onSubmit={handleSignIn} className="flex flex-col gap-4">
            {/* Email Field */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold tracking-wider uppercase text-zinc-400">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full h-11 pl-11 pr-4 rounded-xl text-sm border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-secondary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-secondary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-bold tracking-wider uppercase text-zinc-400">Password</label>
                <button
                  type="button"
                  onClick={() => onNavigate('resetpassword')}
                  className="text-[11px] font-bold text-brand-secondary hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full h-11 pl-11 pr-10 rounded-xl text-sm border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-secondary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-secondary focus:bg-white/75 text-zinc-800'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-300"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Demo Accounts Quick-Fill Hint */}
            <div className={`p-2.5 rounded-xl text-[11px] leading-relaxed transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 border border-zinc-800/35 text-zinc-400' : 'bg-white/55 border border-white/55 text-zinc-500 shadow-sm'
            }`}>
              <span className="font-bold text-brand-secondary block mb-0.5">💡 Demo Accounts:</span>
              <span>Login instantly using <span className="font-bold">demo@chatme.app</span> with password <span className="font-bold">password123</span>.</span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full h-11 rounded-xl bg-brand-secondary text-white font-semibold text-sm hover:bg-blue-600 transition-colors active:scale-98 mt-2 flex items-center justify-center shadow-lg shadow-blue-500/15"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Sign In'
              )}
            </button>

            {/* Navigation Link */}
            <div className="text-center text-xs text-zinc-400 mt-4 font-medium">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => onNavigate('signup')}
                className="font-bold text-brand-primary hover:underline"
              >
                Sign Up
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* ==================== CREATE ACCOUNT SCREEN ==================== */}
      {currentScreen === 'signup' && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="flex flex-col flex-1"
        >
          <div className="mb-4">
            <h2 className="text-2xl font-bold tracking-tight">Create Account</h2>
            <p className="text-xs text-zinc-500 mt-1">Join ChatMe today and start chatting</p>
          </div>

          <form onSubmit={handleSignUp} className="flex flex-col gap-3.5 pb-6">
            {/* PROFILE PHOTO BUTTON */}
            <div className="flex flex-col items-center gap-2.5 my-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handlePhotoUpload}
                accept="image/*"
                className="hidden"
              />
              <div
                onClick={() => fileInputRef.current?.click()}
                style={getAvatarStyle(photo)}
                className="relative w-16 h-16 rounded-2xl cursor-pointer border-2 border-brand-primary shadow-md flex items-center justify-center hover:opacity-90 transition-all overflow-hidden"
              >
                {photo.startsWith('gradient:') && (
                  <Upload size={20} className="text-white drop-shadow-md" />
                )}
              </div>
              <span className="text-[11px] font-bold text-brand-primary tracking-wide cursor-pointer uppercase hover:underline" onClick={() => fileInputRef.current?.click()}>
                Upload Profile Photo
              </span>
            </div>

            {/* Full Name */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Full Name</label>
              <div className="relative">
                <UserIcon size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="text"
                  placeholder="John Doe"
                  value={fullname}
                  onChange={(e) => setFullname(e.target.value)}
                  className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Email Address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Optional Phone */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Phone (Optional)</label>
              <div className="relative">
                <Phone size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Optional Bio */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Bio (Optional)</label>
              <input
                type="text"
                placeholder="Write a tiny bio..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className={`w-full h-10 px-3.5 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                  darkMode
                    ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                    : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                }`}
              />
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="password"
                  placeholder="Min 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Confirm Password */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Confirm Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="password"
                  placeholder="Verify password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-primary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-primary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full h-10 rounded-xl bg-brand-primary text-white font-semibold text-xs hover:bg-emerald-600 transition-colors active:scale-98 mt-2 flex items-center justify-center shadow-lg shadow-emerald-500/15"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Sign Up'
              )}
            </button>

            {/* Navigation Link */}
            <div className="text-center text-xs text-zinc-400 mt-2 font-medium">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => onNavigate('signin')}
                className="font-bold text-brand-secondary hover:underline"
              >
                Sign In
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* ==================== RESET PASSWORD SCREEN ==================== */}
      {currentScreen === 'resetpassword' && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          className="flex flex-col flex-1"
        >
          <div className="mb-6 flex items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigate('signin')}
              className={`p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition-colors`}
            >
              <ArrowLeft size={16} />
            </button>
            <h2 className="text-xl font-bold tracking-tight">Reset Password</h2>
          </div>

          <p className="text-xs text-zinc-500 mb-6 font-medium leading-relaxed">
            Enter the email address associated with your ChatMe account, and we'll send you simulated password reset link instructions.
          </p>

          <form onSubmit={handleResetPassword} className="flex flex-col gap-4">
            {/* Email Field */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold tracking-wider uppercase text-zinc-400">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full h-11 pl-11 pr-4 rounded-xl text-sm border font-medium focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-900/30 border-zinc-800/40 focus:border-brand-secondary focus:bg-zinc-900/50 text-white'
                      : 'bg-white/50 border-white/55 focus:border-brand-secondary focus:bg-white/75 text-zinc-800'
                  }`}
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full h-11 rounded-xl bg-brand-secondary text-white font-semibold text-sm hover:bg-blue-600 transition-colors active:scale-98 mt-2 flex items-center justify-center shadow-lg shadow-blue-500/15"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Send Reset Link'
              )}
            </button>

            {/* Back Link */}
            <button
              type="button"
              onClick={() => onNavigate('signin')}
              className="text-center text-xs text-brand-secondary font-bold hover:underline mt-4 self-center"
            >
              Back to Sign In
            </button>
          </form>
        </motion.div>
      )}

    </div>
  );
}
