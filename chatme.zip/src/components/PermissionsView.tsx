import React from 'react';
import { ArrowLeft, Shield, Bell, MapPin, Camera, Mic, Image, Smartphone } from 'lucide-react';

interface PermissionsViewProps {
  darkMode: boolean;
  onBack: () => void;
}

export default function PermissionsView({ darkMode, onBack }: PermissionsViewProps) {
  const permissions = [
    { name: 'Contacts', icon: Smartphone },
    { name: 'Camera', icon: Camera },
    { name: 'Microphone', icon: Mic },
    { name: 'Photos and Files', icon: Image },
    { name: 'Notifications', icon: Bell },
    { name: 'Location', icon: MapPin },
    { name: 'Storage Access', icon: Shield },
  ];

  return (
    <div className={`w-full h-full flex flex-col justify-start overflow-y-auto transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      <div className={`pt-2 pb-4 px-6 flex items-center gap-3 transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <button
          onClick={onBack}
          className={`p-1.5 rounded-xl transition-colors ${
            darkMode ? 'hover:bg-zinc-800 text-zinc-400 hover:text-white' : 'hover:bg-slate-50 text-zinc-500 hover:text-zinc-900'
          }`}
        >
          <ArrowLeft size={18} />
        </button>
        <h2 className="text-xl font-bold font-display tracking-tight">Permissions</h2>
      </div>

      <div className="p-6 flex flex-col gap-4">
        {permissions.map((p) => (
          <div key={p.name} className={`flex items-center justify-between p-4 rounded-2xl border ${darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'}`}>
            <span className="flex items-center gap-3 text-xs font-semibold">
              <p.icon size={16} />
              {p.name}
            </span>
            <button className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-300 relative ${darkMode ? 'bg-brand-primary' : 'bg-zinc-350'}`}>
              <div className={`w-5 h-5 rounded-full bg-white shadow-md transform translate-x-5`} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
