/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Edit3, Settings, LogOut, Check, X, Phone, Mail, FileText, Camera, User as UserIcon } from 'lucide-react';
import { User } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface ProfileTabProps {
  currentUser: User;
  onUpdateUser: (updatedUser: User) => void;
  onNavigateToSettings: () => void;
  onLogout: () => void;
  darkMode: boolean;
}

export default function ProfileTab({
  currentUser,
  onUpdateUser,
  onNavigateToSettings,
  onLogout,
  darkMode,
}: ProfileTabProps) {
  
  // Edit states
  const [isEditing, setIsEditing] = useState(false);
  const [fullname, setFullname] = useState(currentUser.fullname);
  const [phone, setPhone] = useState(currentUser.phone);
  const [bio, setBio] = useState(currentUser.bio);
  const [photo, setPhoto] = useState(currentUser.photo);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File to base64 converter
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrorMsg('Photo must be smaller than 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
        setErrorMsg('');
      };
      reader.readAsDataURL(file);
    }
  };

  // Save changes submit
  const handleSave = () => {
    if (!fullname.trim()) {
      setErrorMsg('Full name cannot be empty');
      return;
    }

    const updated: User = {
      ...currentUser,
      fullname: fullname.trim(),
      phone: phone.trim(),
      bio: bio.trim(),
      photo: photo,
    };

    ChatMeDB.updateUser(updated);
    onUpdateUser(updated);
    setIsEditing(false);
    setErrorMsg('');
  };

  const handleCancel = () => {
    setFullname(currentUser.fullname);
    setPhone(currentUser.phone);
    setBio(currentUser.bio);
    setPhoto(currentUser.photo);
    setIsEditing(false);
    setErrorMsg('');
  };

  return (
    <div className={`flex-1 flex flex-col h-full overflow-y-auto select-none transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Header bar */}
      <div className={`pt-2 pb-4 px-6 flex justify-between items-center transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <h2 className="text-2xl font-bold font-display tracking-tight">My Profile</h2>
        
        {/* Toggle Edit action */}
        {!isEditing && (
          <button
            onClick={() => setIsEditing(true)}
            className={`p-2 rounded-xl transition-colors ${
              darkMode 
                ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' 
                : 'text-zinc-500 hover:text-zinc-900 hover:bg-slate-50'
            }`}
          >
            <Edit3 size={18} />
          </button>
        )}
      </div>

      <div className="flex-1 p-6 flex flex-col items-center bg-transparent">
        
        {/* Avatar Area */}
        <div className="relative group mb-5">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handlePhotoUpload}
            accept="image/*"
            className="hidden"
            disabled={!isEditing}
          />
          <div
            style={getAvatarStyle(photo)}
            className={`w-28 h-28 rounded-3xl flex items-center justify-center text-white text-4xl font-extrabold font-display border-4 shadow-xl transition-all relative ${
              isEditing ? 'border-brand-primary cursor-pointer hover:brightness-90' : 'border-zinc-100 dark:border-zinc-800'
            }`}
            onClick={() => isEditing && fileInputRef.current?.click()}
          >
            {photo.startsWith('gradient:') && getInitials(fullname)}

            {/* Overlap camera badge during edit mode */}
            {isEditing && (
              <div className="absolute inset-0 bg-black/40 rounded-3xl flex items-center justify-center text-white">
                <Camera size={24} className="drop-shadow-md" />
              </div>
            )}
          </div>
        </div>

        {/* Name / Email labels */}
        {!isEditing ? (
          <div className="text-center mb-8">
            <h3 className={`text-xl font-bold tracking-tight ${darkMode ? 'text-zinc-100' : 'text-zinc-850'}`}>
              {currentUser.fullname}
            </h3>
            <span className="text-[11px] font-mono font-semibold text-zinc-400 block mt-1 tracking-wider uppercase">
              {currentUser.email}
            </span>
          </div>
        ) : (
          <div className="w-full flex flex-col gap-3.5 mb-6">
            {errorMsg && (
              <div className="p-2 text-[11px] font-bold text-red-500 bg-red-100/10 rounded-xl text-center">
                {errorMsg}
              </div>
            )}

            {/* Edit fullname */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Full Name</label>
              <div className="relative">
                <UserIcon size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="text"
                  value={fullname}
                  onChange={(e) => setFullname(e.target.value)}
                  className={`w-full h-9 pl-9 pr-4 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-850 focus:bg-zinc-800 border border-zinc-800 text-white'
                      : 'bg-slate-50 focus:bg-white border border-zinc-200 text-zinc-800'
                  }`}
                />
              </div>
            </div>
          </div>
        )}

        {/* Details Fields Box */}
        <div className="w-full flex flex-col gap-4">
          
          {/* Bio record */}
          <div className={`p-4 rounded-2xl flex items-start gap-4 border transition-all duration-300 ${
            darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
          }`}>
            <FileText size={18} className="text-brand-primary shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">Bio</span>
              {isEditing ? (
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={2}
                  className={`w-full p-2 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-800 border border-zinc-750 text-white'
                      : 'bg-white border border-zinc-200 text-zinc-800'
                  }`}
                />
              ) : (
                <p className={`text-xs font-semibold leading-relaxed ${darkMode ? 'text-zinc-200' : 'text-zinc-700'}`}>
                  {currentUser.bio}
                </p>
              )}
            </div>
          </div>

          {/* Phone record */}
          <div className={`p-4 rounded-2xl flex items-start gap-4 border transition-all duration-300 ${
            darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
          }`}>
            <Phone size={18} className="text-brand-secondary shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">Phone Number</span>
              {isEditing ? (
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full h-8 px-2 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
                    darkMode
                      ? 'bg-zinc-800 border border-zinc-750 text-white'
                      : 'bg-white border border-zinc-200 text-zinc-800'
                  }`}
                />
              ) : (
                <p className={`text-xs font-semibold leading-relaxed ${darkMode ? 'text-zinc-200' : 'text-zinc-700'}`}>
                  {currentUser.phone}
                </p>
              )}
            </div>
          </div>

          {/* Email record */}
          {!isEditing && (
            <div className={`p-4 rounded-2xl flex items-start gap-4 border transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
            }`}>
              <Mail size={18} className="text-zinc-400 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">Registered Email</span>
                <p className={`text-xs font-semibold leading-relaxed ${darkMode ? 'text-zinc-200' : 'text-zinc-700'}`}>
                  {currentUser.email}
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Editing buttons row */}
        {isEditing && (
          <div className="flex items-center gap-3 w-full mt-6">
            <button
              onClick={handleCancel}
              className="flex-1 h-10 rounded-xl bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-750 text-zinc-700 dark:text-zinc-200 font-bold text-xs transition-colors flex items-center justify-center gap-1"
            >
              <X size={14} /> Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex-1 h-10 rounded-xl bg-brand-primary hover:bg-emerald-600 text-white font-bold text-xs transition-all flex items-center justify-center gap-1 shadow-lg shadow-emerald-500/10"
            >
              <Check size={14} /> Save Changes
            </button>
          </div>
        )}

        {/* General Action Navigation rows (Settings & Logout) */}
        {!isEditing && (
          <div className="w-full flex flex-col gap-2 mt-8">
            {/* Open Settings button */}
            <button
              onClick={onNavigateToSettings}
              className={`w-full h-11 px-4 rounded-xl border flex items-center justify-between font-semibold text-xs transition-all duration-300 hover:scale-99 active:scale-98 text-left ${
                darkMode
                  ? 'bg-zinc-900/40 hover:bg-zinc-800/40 border-zinc-800/40 text-zinc-200'
                  : 'bg-white/50 hover:bg-white/70 border-white/55 text-zinc-850 shadow-sm'
              }`}
            >
              <span className="flex items-center gap-3">
                <Settings size={16} className="text-brand-secondary" /> App Settings
              </span>
              <span className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider">CONFIGURE</span>
            </button>

            {/* Logout button */}
            <button
              onClick={onLogout}
              className={`w-full h-11 px-4 rounded-xl border flex items-center justify-between font-semibold text-xs transition-all duration-300 hover:scale-99 active:scale-98 text-left ${
                darkMode
                  ? 'bg-red-950/20 hover:bg-red-900/20 border-red-900/40 text-red-400'
                  : 'bg-red-50/50 hover:bg-red-50/85 border-red-100/70 text-red-600'
              }`}
            >
              <span className="flex items-center gap-3">
                <LogOut size={16} /> Sign Out Session
              </span>
              <span className="text-[10px] font-mono font-bold opacity-60 tracking-wider">EXIT</span>
            </button>
          </div>
        )}

      </div>

    </div>
  );
}
