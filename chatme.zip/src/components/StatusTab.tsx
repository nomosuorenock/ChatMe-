import { useState } from 'react';
import { Camera, Plus, Circle, Lock, X } from 'lucide-react';
import { User } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface StatusTabProps {
  currentUser: User;
  darkMode: boolean;
}

export default function StatusTab({ currentUser, darkMode }: StatusTabProps) {
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [privacy, setPrivacy] = useState<'contacts' | 'except' | 'only'>('contacts');

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden select-none transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      <div className={`pt-2 pb-4 px-6 flex justify-between items-center transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <h2 className="text-2xl font-bold font-display tracking-tight">Status</h2>
        <button onClick={() => setShowPrivacyModal(true)} className="p-2 text-zinc-500 hover:text-brand-primary">
          <Lock size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto bg-transparent p-6">
        {/* My Status */}
        <div className="flex items-center gap-4 mb-8">
          <div className="relative">
            <div className="w-14 h-14 rounded-full bg-zinc-300 overflow-hidden">
              <img src={currentUser.photo} alt={currentUser.fullname} className="w-full h-full object-cover" />
            </div>
            <button className="absolute bottom-0 right-0 p-1 bg-brand-primary rounded-full border-2 border-zinc-950">
              <Plus size={16} className="text-white" />
            </button>
          </div>
          <div>
            <h3 className="font-bold">My Status</h3>
            <p className="text-xs text-zinc-500">Tap to add status update</p>
          </div>
        </div>

        <h4 className="text-xs font-bold text-zinc-500 mb-4 uppercase tracking-wider">Recent Updates</h4>
        <div className="text-center py-12 text-zinc-500 text-sm">
          No recent status updates
        </div>
      </div>

      {/* Privacy Modal */}
      <AnimatePresence>
        {showPrivacyModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
            onClick={() => setShowPrivacyModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className={`w-full max-w-sm p-6 rounded-3xl ${darkMode ? 'bg-zinc-900' : 'bg-white'}`}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold">Status Privacy</h3>
                <button onClick={() => setShowPrivacyModal(false)}><X size={20} /></button>
              </div>
              <div className="space-y-4">
                {(['contacts', 'except', 'only'] as const).map((option) => (
                  <button
                    key={option}
                    onClick={() => setPrivacy(option)}
                    className={`w-full text-left p-4 rounded-xl flex items-center gap-3 ${privacy === option ? 'bg-brand-primary/10 text-brand-primary' : darkMode ? 'bg-zinc-800' : 'bg-zinc-100'}`}
                  >
                    <Circle size={20} className={privacy === option ? 'fill-current' : ''} />
                    <span className="capitalize">{option}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
