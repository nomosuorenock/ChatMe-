import { useState } from 'react';
import { Send, Bot, User } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatBotTabProps {
  darkMode: boolean;
}

export default function ChatBotTab({ darkMode }: ChatBotTabProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input, history: messages }),
      });
      const data = await response.json();
      
      const botMessage: Message = { role: 'assistant', content: data.response };
      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`flex-1 flex flex-col h-full ${darkMode ? 'bg-zinc-950 text-white' : 'bg-white text-zinc-900'}`}>
      <div className={`p-4 border-b ${darkMode ? 'border-zinc-800' : 'border-zinc-200'}`}>
        <h2 className="text-xl font-bold flex items-center gap-2">
            <Bot size={24} className="text-brand-primary" />
            ChatMe AI Assistant
        </h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-2xl ${msg.role === 'user' ? 'bg-brand-primary text-white' : darkMode ? 'bg-zinc-800' : 'bg-zinc-100'}`}>
              {msg.content}
            </div>
          </div>
        ))}
        {loading && <div className="text-sm text-zinc-500">Assistant is typing...</div>}
      </div>

      <div className={`p-4 border-t flex gap-2 ${darkMode ? 'border-zinc-800 bg-zinc-900' : 'border-zinc-200 bg-white'}`}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask anything..."
          className="flex-1 bg-transparent p-2 outline-none"
        />
        <button onClick={sendMessage} disabled={loading} className="text-brand-primary">
          <Send size={20} />
        </button>
      </div>
    </div>
  );
}
