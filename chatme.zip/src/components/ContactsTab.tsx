/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, UserPlus, Users } from 'lucide-react';
import { User } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface ContactsTabProps {
  currentUser: User;
  onSelectContact: (contact: User) => void;
  darkMode: boolean;
}

export default function ContactsTab({ currentUser, onSelectContact, darkMode }: ContactsTabProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // 1. Get all registered users from mock DB, except current user
  const users = ChatMeDB.getUsers().filter((u) => u.id !== currentUser.id);

  // 2. Filter list by search query
  const filteredUsers = users.filter((u) =>
    u.fullname.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.bio.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // 3. Group by alphabetical letter headings
  const alphabetGroups: Record<string, User[]> = {};
  filteredUsers
    .sort((a, b) => a.fullname.localeCompare(b.fullname))
    .forEach((user) => {
      const firstLetter = user.fullname.charAt(0).toUpperCase();
      if (!alphabetGroups[firstLetter]) {
        alphabetGroups[firstLetter] = [];
      }
      alphabetGroups[firstLetter].push(user);
    });

  const sortedLetters = Object.keys(alphabetGroups).sort();

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden select-none transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Top Header */}
      <div className={`pt-2 pb-4 px-6 flex justify-between items-center transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <h2 className="text-2xl font-bold font-display tracking-tight">Contacts</h2>
        <span className="text-[11px] font-bold bg-brand-primary/10 text-brand-primary px-2.5 py-1 rounded-full font-sans">
          {users.length} Total
        </span>
      </div>

      {/* Modern Search Input bar */}
      <div className={`px-6 py-3 transition-all duration-300 ${
        darkMode ? 'bg-zinc-900/35' : 'bg-white/35'
      }`}>
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search contact names or bios..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full h-10 pl-10 pr-4 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
              darkMode
                ? 'bg-zinc-900/30 focus:bg-zinc-900/50 border border-zinc-800/40 text-white placeholder-zinc-500'
                : 'bg-white/50 focus:bg-white/70 border border-white/55 text-zinc-800 placeholder-zinc-400'
            }`}
          />
        </div>
      </div>

      {/* Contacts Alphabetic Scrollable Container */}
      <div className="flex-1 overflow-y-auto bg-transparent">
        {sortedLetters.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-80 px-8 text-center">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-colors ${
              darkMode ? 'bg-zinc-800/45 text-zinc-600' : 'bg-white/45 text-slate-300'
            }`}>
              <Users size={28} />
            </div>
            <p className="text-sm font-semibold text-zinc-400">No contacts matching search</p>
            <p className="text-xs text-zinc-500 mt-1">Try searching for other pre-seeded friends!</p>
          </div>
        ) : (
          <div>
            {sortedLetters.map((letter) => (
              <div key={letter} className="flex flex-col">
                {/* Alphabet letter heading block */}
                <div className={`text-[11px] font-bold px-6 py-1.5 font-sans tracking-wider transition-all duration-300 ${
                  darkMode ? 'bg-zinc-950/50 text-brand-secondary' : 'bg-white/50 text-brand-secondary border-y border-white/25'
                }`}>
                  {letter}
                </div>

                {/* Contacts inside this letter group */}
                <div className="divide-y divide-white/10 dark:divide-zinc-800/25">
                  {alphabetGroups[letter].map((contact) => (
                    <div
                      key={contact.id}
                      onClick={() => onSelectContact(contact)}
                      className={`flex items-center gap-4 py-3 px-6 cursor-pointer transition-all duration-200 ${
                        darkMode ? 'hover:bg-zinc-800/35' : 'hover:bg-white/35'
                      }`}
                    >
                      {/* Avatar picture */}
                      <div className="relative shrink-0">
                        <div
                          style={getAvatarStyle(contact.photo)}
                          className="w-11 h-11 rounded-[12px] flex items-center justify-center text-white font-bold font-display text-sm border border-transparent shadow-sm"
                        >
                          {contact.photo.startsWith('gradient:') && getInitials(contact.fullname)}
                        </div>
                        {/* Live status dot */}
                        {contact.isOnline && (
                          <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-brand-primary border-2 border-white dark:border-zinc-900 rounded-full shadow-sm" />
                        )}
                      </div>

                      {/* Name & Bio Details */}
                      <div className="flex-1 min-w-0">
                        <h4 className={`text-[13px] font-bold truncate tracking-tight ${
                          darkMode ? 'text-zinc-100' : 'text-zinc-850'
                        }`}>
                          {contact.fullname}
                        </h4>
                        <p className="text-[11px] text-zinc-500 truncate mt-0.5 font-medium">
                          {contact.bio}
                        </p>
                      </div>

                      {/* Online status label */}
                      <span className={`text-[10px] font-semibold tracking-wide capitalize ${
                        contact.isOnline ? 'text-brand-primary' : 'text-zinc-400'
                      }`}>
                        {contact.isOnline ? 'Online' : 'Offline'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
