/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Moon, Sun, Bell, Shield, Lock, Info, HelpCircle, LogOut, CheckCircle2, AlertCircle, Smartphone } from 'lucide-react';
import { User, AppSettings } from '../types';
import { ChatMeDB } from '../lib/database';
import PermissionsView from './PermissionsView';

interface SettingsViewProps {
  currentUser: User;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
  onBack: () => void;
  onLogout: () => void;
  darkMode: boolean;
}

export default function SettingsView({
  currentUser,
  settings,
  onUpdateSettings,
  onBack,
  onLogout,
  darkMode,
}: SettingsViewProps) {
  
  // Change Password state
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');

  // Permissions state
  const [showPermissions, setShowPermissions] = useState(false);

  // Info segments
  const [showAbout, setShowAbout] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  // Toggle helpers
  const handleToggleDarkMode = () => {
    onUpdateSettings({ ...settings, darkMode: !settings.darkMode });
  };

  const handleToggleNotifications = () => {
    onUpdateSettings({ ...settings, notificationsEnabled: !settings.notificationsEnabled });
  };

  const handleTogglePrivacy = () => {
    onUpdateSettings({ ...settings, privacyLocked: !settings.privacyLocked });
  };

  if (showPermissions) {
    return <PermissionsView darkMode={darkMode} onBack={() => setShowPermissions(false)} />;
  }

  // Change password submit handler
  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPwdError('');
    setPwdSuccess('');

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setPwdError('Please fill in all fields');
      return;
    }

    if (newPassword.length < 6) {
      setPwdError('New password must be at least 6 characters');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPwdError('New passwords do not match');
      return;
    }

    // Verify current password
    const users = ChatMeDB.getUsers();
    const updatedUsers = users.map((u) => {
      if (u.id === currentUser.id) {
        if (u.password && u.password !== currentPassword) {
          setPwdError('Current password is incorrect');
          return u;
        }
        // Match! Update
        setPwdSuccess('Password updated successfully!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        return { ...u, password: newPassword };
      }
      return u;
    });

    if (!pwdError) {
      ChatMeDB.setStorageItem('users', updatedUsers);
    }
  };

  return (
    <div className={`w-full h-full flex flex-col justify-start overflow-y-auto transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* Header bar */}
      <div className={`pt-2 pb-4 px-6 flex items-center gap-3 transition-all duration-300 border-b ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <button
          onClick={onBack}
          className={`p-1.5 rounded-xl transition-colors ${
            darkMode ? 'hover:bg-zinc-800 text-zinc-400 hover:text-white' : 'hover:bg-slate-50 text-zinc-500 hover:text-zinc-900'
          }`}
        >
          <ArrowLeft size={18} />
        </button>
        <h2 className="text-xl font-bold font-display tracking-tight">Settings</h2>
      </div>

      {/* Settings Options container */}
      <div className="p-6 flex flex-col gap-5">
        
        {/* Toggle options group */}
        <div className="flex flex-col gap-3">
          <span className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">General Configuration</span>

          {/* Dark Mode toggle row */}
          <div className={`flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${
            darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
          }`}>
            <span className="flex items-center gap-3 text-xs font-semibold">
              {darkMode ? <Moon size={16} className="text-brand-secondary" /> : <Sun size={16} className="text-amber-500" />}
              Dark Theme Mode
            </span>
            <button
              onClick={handleToggleDarkMode}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-300 relative ${
                darkMode ? 'bg-brand-primary' : 'bg-zinc-350'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-300 ${
                darkMode ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* Permissions link row */}
          <button
            onClick={() => setShowPermissions(true)}
            className={`w-full text-left p-4 rounded-2xl border flex items-center justify-between transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 hover:bg-zinc-800/40 border-zinc-800/35 text-zinc-100' : 'bg-white/50 hover:bg-white/70 border-white/55 text-zinc-800 shadow-sm'
            }`}
          >
            <span className="flex items-center gap-3 text-xs font-semibold">
              <Smartphone size={16} className="text-zinc-400" />
              Device Permissions
            </span>
            <span className="text-[10px] font-bold text-zinc-400">CONFIGURE</span>
          </button>

          {/* Notifications toggle row */}
          <div className={`flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${
            darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
          }`}>
            <span className="flex items-center gap-3 text-xs font-semibold">
              <Bell size={16} className="text-emerald-500" />
              Push Alert Notifications
            </span>
            <button
              onClick={handleToggleNotifications}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-300 relative ${
                settings.notificationsEnabled ? 'bg-brand-primary' : 'bg-zinc-350'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-300 ${
                settings.notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* Privacy lock toggle row */}
          <div className={`flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${
            darkMode ? 'bg-zinc-900/40 border-zinc-800/35' : 'bg-white/50 border-white/55 shadow-sm'
          }`}>
            <span className="flex items-center gap-3 text-xs font-semibold">
              <Shield size={16} className="text-blue-500" />
              Incognito Read Receipts
            </span>
            <button
              onClick={handleTogglePrivacy}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-300 relative ${
                settings.privacyLocked ? 'bg-brand-primary' : 'bg-zinc-350'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-300 ${
                settings.privacyLocked ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>
        </div>

        {/* Change Password Panel */}
        <div className="flex flex-col gap-2.5">
          <span className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Security & Credentials</span>
          
          <button
            onClick={() => setShowChangePassword(!showChangePassword)}
            className={`w-full text-left p-4 rounded-2xl border flex items-center justify-between transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 hover:bg-zinc-800/40 border-zinc-800/35 text-zinc-100' : 'bg-white/50 hover:bg-white/70 border-white/55 text-zinc-800 shadow-sm'
            }`}
          >
            <span className="flex items-center gap-3 text-xs font-semibold">
              <Lock size={16} className="text-zinc-400" />
              Change Password Account
            </span>
            <span className="text-[10px] font-bold text-zinc-400">{showChangePassword ? 'HIDE' : 'SHOW'}</span>
          </button>

          {showChangePassword && (
            <motion.form
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              onSubmit={handleChangePasswordSubmit}
              className={`p-4 rounded-2xl border flex flex-col gap-3 transition-colors ${
                darkMode ? 'bg-zinc-950/40 border-zinc-850' : 'bg-white border-zinc-200'
              }`}
            >
              {pwdError && (
                <div className="p-2 bg-red-100/10 text-red-500 text-[11px] font-bold rounded-xl flex items-center gap-2">
                  <AlertCircle size={14} /> {pwdError}
                </div>
              )}
              {pwdSuccess && (
                <div className="p-2 bg-emerald-100/10 text-emerald-500 text-[11px] font-bold rounded-xl flex items-center gap-2">
                  <CheckCircle2 size={14} /> {pwdSuccess}
                </div>
              )}

              {/* Current Password */}
              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">Current Password</label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className={`w-full h-8 px-2 rounded-lg text-xs font-semibold focus:outline-none transition-all ${
                    darkMode ? 'bg-zinc-850 border border-zinc-800 text-white' : 'bg-slate-50 border border-zinc-200 text-zinc-850'
                  }`}
                />
              </div>

              {/* New Password */}
              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className={`w-full h-8 px-2 rounded-lg text-xs font-semibold focus:outline-none transition-all ${
                    darkMode ? 'bg-zinc-850 border border-zinc-800 text-white' : 'bg-slate-50 border border-zinc-200 text-zinc-850'
                  }`}
                />
              </div>

              {/* Confirm New Password */}
              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">Confirm New Password</label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  className={`w-full h-8 px-2 rounded-lg text-xs font-semibold focus:outline-none transition-all ${
                    darkMode ? 'bg-zinc-850 border border-zinc-800 text-white' : 'bg-slate-50 border border-zinc-200 text-zinc-850'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full h-8 rounded-lg bg-brand-secondary hover:bg-blue-600 text-white text-xs font-bold transition-colors"
              >
                Change Password
              </button>
            </motion.form>
          )}
        </div>

        {/* Informative / Help sections */}
        <div className="flex flex-col gap-2.5">
          <span className="text-[10px] font-bold tracking-wider uppercase text-zinc-400">Information & Support</span>

          {/* Help panel */}
          <button
            onClick={() => { setShowHelp(!showHelp); setShowAbout(false); }}
            className={`w-full text-left p-4 rounded-2xl border flex items-center justify-between transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 hover:bg-zinc-800/40 border-zinc-800/35 text-zinc-100' : 'bg-white/50 hover:bg-white/70 border-white/55 text-zinc-800 shadow-sm'
            }`}
          >
            <span className="flex items-center gap-3 text-xs font-semibold">
              <HelpCircle size={16} className="text-zinc-400" />
              Help & FAQ Documentation
            </span>
            <span className="text-[10px] font-bold text-zinc-400">{showHelp ? 'HIDE' : 'READ'}</span>
          </button>

          {showHelp && (
            <div className={`p-4 rounded-2xl border text-xs leading-relaxed transition-all duration-300 ${
              darkMode ? 'bg-zinc-950/40 border-zinc-800/35 text-zinc-350' : 'bg-white/45 border-white/40 text-zinc-650 shadow-sm'
            }`}>
              <h5 className="font-bold text-brand-primary mb-1">Frequently Asked Questions:</h5>
              <p className="mb-2"><span className="font-bold">Q: How do calls work?</span><br />A: Tapping the phone/camera icon inside chats triggers a high-fidelity sound synthesis calling screen. After 3 seconds, they automatically "connect"!</p>
              <p><span className="font-bold">Q: How do contacts reply?</span><br />A: Pre-seeded contacts have built-in intelligent reply simulators. Once you send a message, they display a "typing..." status and reply within a couple of seconds.</p>
            </div>
          )}

          {/* About panel */}
          <button
            onClick={() => { setShowAbout(!showAbout); setShowHelp(false); }}
            className={`w-full text-left p-4 rounded-2xl border flex items-center justify-between transition-all duration-300 ${
              darkMode ? 'bg-zinc-900/40 hover:bg-zinc-800/40 border-zinc-800/35 text-zinc-100' : 'bg-white/50 hover:bg-white/70 border-white/55 text-zinc-800 shadow-sm'
            }`}
          >
            <span className="flex items-center gap-3 text-xs font-semibold">
              <Info size={16} className="text-zinc-400" />
              About ChatMe Release
            </span>
            <span className="text-[10px] font-bold text-zinc-400">{showAbout ? 'HIDE' : 'READ'}</span>
          </button>

          {showAbout && (
            <div className={`p-4 rounded-2xl border text-xs leading-relaxed transition-all duration-300 ${
              darkMode ? 'bg-zinc-950/40 border-zinc-800/35 text-zinc-350' : 'bg-white/45 border-white/40 text-zinc-650 shadow-sm'
            }`}>
              <p className="font-bold">ChatMe Applet v1.0.0</p>
              <p className="mt-1">A highly responsive React 19 mobile layout featuring rich local database storage state, sound effects audio synthesis, and interactive front-facing camera feeds.</p>
              <p className="text-[10px] text-zinc-400 mt-2 font-mono">Released: July 2026</p>
            </div>
          )}
        </div>

        {/* Global Logout Shortcut */}
        <button
          onClick={onLogout}
          className={`w-full h-11 px-4 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition-all hover:scale-99 active:scale-98 ${
            darkMode
              ? 'bg-red-950/20 hover:bg-red-900/20 border-red-900/45 text-red-400 shadow-sm'
              : 'bg-red-50/50 hover:bg-red-50/85 border-red-100/70 text-red-600 shadow-sm'
          }`}
        >
          <LogOut size={16} /> Sign Out Session
        </button>

      </div>

    </div>
  );
}
