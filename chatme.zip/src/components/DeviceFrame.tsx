/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
  darkMode: boolean;
}

export default function DeviceFrame({ children, darkMode }: DeviceFrameProps) {
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // key 0 to 12
      setCurrentTime(`${hours}:${minutes} ${ampm}`);
    };

    updateClock();
    const interval = setInterval(updateClock, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`flex items-center justify-center min-h-screen p-4 transition-all duration-500 ${
      darkMode 
        ? 'bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950' 
        : 'bg-gradient-to-br from-[#22C55E]/15 via-slate-50 to-[#3B82F6]/15'
    }`}>
      {/* Phone Case Bezel */}
      <div className={`relative w-full max-w-[412px] h-[840px] rounded-[40px] border-8 shadow-2xl overflow-hidden flex flex-col transition-all duration-500 ${
        darkMode 
          ? 'border-zinc-800 bg-gradient-to-br from-zinc-900 via-zinc-950 to-zinc-900 shadow-zinc-950/80' 
          : 'border-zinc-300/85 bg-gradient-to-br from-[#22C55E]/10 via-white/80 to-[#3B82F6]/10 shadow-slate-300/60'
      }`}>
        
        {/* Top Notch / Camera Cutout */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-full z-50 flex items-center justify-center">
          <div className="w-3 h-3 bg-zinc-900 rounded-full border border-zinc-800 flex items-center justify-center">
            <div className="w-1 h-1 bg-blue-900 rounded-full" />
          </div>
          <div className="w-12 h-1 bg-zinc-850 rounded-full ml-4" />
        </div>

        {/* Device Status Bar */}
        <div className={`w-full h-11 pt-3 px-6 flex justify-between items-center z-40 select-none text-[12px] font-semibold tracking-tight transition-colors duration-300 ${
          darkMode 
            ? 'text-zinc-350 bg-black/15 backdrop-blur-md' 
            : 'text-zinc-650 bg-white/30 backdrop-blur-md border-b border-white/20'
        }`}>
          <span>{currentTime}</span>
          <div className="flex items-center gap-1.5">
            <Signal size={14} className="opacity-90" />
            <Wifi size={14} className="opacity-90" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] font-bold">94%</span>
              <Battery size={14} className="rotate-0 opacity-90" />
            </div>
          </div>
        </div>

        {/* Screen Area */}
        <div id="phone-screen" className="flex-1 flex flex-col overflow-hidden relative">
          {children}
        </div>

        {/* Android Pill Bottom Handle */}
        <div className={`w-full h-5 flex justify-center items-center pb-1 z-40 transition-colors duration-300 ${
          darkMode 
            ? 'bg-black/15 backdrop-blur-md' 
            : 'bg-white/30 backdrop-blur-md border-t border-white/20'
        }`}>
          <div className="w-28 h-1 rounded-full bg-zinc-400/80 opacity-60" />
        </div>
      </div>
    </div>
  );
}
