/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Phone, Video, Smile, Paperclip, Camera, Send, Check, CheckCheck, FileText, Image as ImageIcon, X } from 'lucide-react';
import { User, ChatMessage } from '../types';
import { ChatMeDB, getAvatarStyle, getInitials } from '../lib/database';

interface ChatRoomViewProps {
  currentUser: User;
  contact: User;
  onBack: () => void;
  onInitiateCall: (contact: User, type: 'voice' | 'video') => void;
  darkMode: boolean;
}

export default function ChatRoomView({
  currentUser,
  contact,
  onBack,
  onInitiateCall,
  darkMode,
}: ChatRoomViewProps) {
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Emoji Drawer & Attachment states
  const [showEmojiTray, setShowEmojiTray] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<{ name: string; size: string; type: string; url?: string } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Popular Emojis for quick selector tray
  const popularEmojis = ['😂', '👍', '❤️', '🔥', '🎉', '👀', '😍', '💻', '🚀', '✨', '👌', '👏', '🤔', '☕'];

  // 1. Fetch current threads on mount
  useEffect(() => {
    const fetchThreads = () => {
      const threads = ChatMeDB.getChatsForUser(currentUser.id);
      const filtered = threads.filter(
        (msg) =>
          (msg.sender_id === currentUser.id && msg.receiver_id === contact.id) ||
          (msg.sender_id === contact.id && msg.receiver_id === currentUser.id)
      );
      setMessages(filtered);

      // Mark unread messages as read
      ChatMeDB.markChatsAsRead(contact.id, currentUser.id);
    };

    fetchThreads();
    // Auto scroll
    scrollToBottom();
  }, [contact.id, currentUser.id]);

  // Scroll Helper
  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // 2. Synthesize Beep Sound on receiving message
  const playIncomingBeep = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = audioContextRef.current || new AudioCtx();
      audioContextRef.current = ctx;

      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
      
      gainNode.gain.setValueAtTime(0, ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.05);
      gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.25);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {}
  };

  // 3. User submits message
  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    // Validate empty messages or empty attachments
    if (!inputText.trim() && !selectedImage && !selectedFile) return;

    // Create message data
    const messagePayload: Omit<ChatMessage, 'id' | 'timestamp' | 'status'> = {
      sender_id: currentUser.id,
      receiver_id: contact.id,
      message: inputText.trim(),
    };

    if (selectedImage) {
      messagePayload.image = selectedImage;
    }

    if (selectedFile) {
      messagePayload.file = selectedFile;
    }

    // Save to Database
    const newMsg = ChatMeDB.addChatMessage(messagePayload);
    
    // Update local state thread
    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
    setSelectedImage(null);
    setSelectedFile(null);
    setShowEmojiTray(false);
    scrollToBottom();

    // 4. Trigger Smart Response typing simulation
    // Typing indicators & Automated replies from pre-seeded contacts
    setIsTyping(true);
    
    const typingInterval = setTimeout(() => {
      setIsTyping(false);

      // Get reply text
      const replyText = ChatMeDB.getSimulatedReply(contact.id, newMsg.message);
      
      // Save Reply message to DB
      const replyMsg = ChatMeDB.addChatMessage({
        sender_id: contact.id,
        receiver_id: currentUser.id,
        message: replyText,
      });

      // Update local state and play beep sound
      setMessages((prev) => [...prev, replyMsg]);
      playIncomingBeep();
      scrollToBottom();
    }, 2500);

    return () => clearTimeout(typingInterval);
  };

  // Attach Image handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setSelectedFile(null); // Clear document file if image is selected
        scrollToBottom();
      };
      reader.readAsDataURL(file);
    }
  };

  // Attach File handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setSelectedFile({
        name: file.name,
        size: `${sizeMB} MB`,
        type: file.type || 'document/bin',
      });
      setSelectedImage(null); // Clear image if document selected
      scrollToBottom();
    }
  };

  const handleEmojiClick = (emoji: string) => {
    setInputText((prev) => prev + emoji);
  };

  // Format single message time
  const formatTimeStr = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden select-none relative transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
    }`}>
      
      {/* 1. TOP HEADER ACTION BAR */}
      <div className={`py-2 px-4 flex items-center justify-between transition-all duration-300 border-b z-30 ${
        darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
      }`}>
        <div className="flex items-center gap-2.5 min-w-0">
          {/* Back button */}
          <button
            onClick={onBack}
            className={`p-1.5 rounded-xl transition-colors ${
              darkMode ? 'hover:bg-zinc-800 text-zinc-400 hover:text-white' : 'hover:bg-slate-50 text-zinc-500 hover:text-zinc-900'
            }`}
          >
            <ArrowLeft size={18} />
          </button>

          {/* Contact photo */}
          <div className="relative shrink-0">
            <div
              style={getAvatarStyle(contact.photo)}
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold font-display text-xs shadow-sm border border-transparent"
            >
              {contact.photo.startsWith('gradient:') && getInitials(contact.fullname)}
            </div>
            {contact.isOnline && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-brand-primary border-2 border-white dark:border-zinc-900 rounded-full shadow-sm" />
            )}
          </div>

          {/* Peer Details */}
          <div className="min-w-0">
            <h4 className={`text-xs font-bold truncate leading-tight ${darkMode ? 'text-zinc-150' : 'text-zinc-800'}`}>
              {contact.fullname}
            </h4>
            <span className={`text-[9px] font-bold block ${
              isTyping ? 'text-brand-primary' : contact.isOnline ? 'text-brand-primary' : 'text-zinc-400'
            }`}>
              {isTyping ? 'typing...' : contact.isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>

        {/* Dialers */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onInitiateCall(contact, 'voice')}
            className={`p-2 rounded-xl transition-colors ${
              darkMode ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-zinc-500 hover:text-zinc-900 hover:bg-slate-50'
            }`}
          >
            <Phone size={16} />
          </button>
          <button
            onClick={() => onInitiateCall(contact, 'video')}
            className={`p-2 rounded-xl transition-colors ${
              darkMode ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-zinc-500 hover:text-zinc-900 hover:bg-slate-50'
            }`}
          >
            <Video size={16} />
          </button>
        </div>
      </div>

      {/* 2. CHATS SCROLLABLE BODY */}
      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3.5 bg-transparent">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center opacity-60 px-6 py-12">
            <span className="text-[10px] font-bold tracking-widest text-zinc-400 font-mono uppercase bg-zinc-200/50 dark:bg-zinc-850 p-2 rounded-xl">
              Secure Chat Active
            </span>
            <p className="text-[11px] font-medium text-zinc-500 leading-relaxed mt-2.5">
              This conversation is completely localized and encrypted inside the frame. Say hi to start the simulated chat!
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.sender_id === currentUser.id;
            return (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[80%] ${
                  isMe ? 'self-end items-end' : 'self-start items-start'
                }`}
              >
                {/* Bubble card */}
                <div className={`p-3 rounded-2xl text-[12px] leading-relaxed shadow-sm font-medium border backdrop-blur-sm transition-all duration-300 ${
                  isMe
                    ? 'bg-brand-primary/90 text-white border-brand-primary/20 rounded-tr-none'
                    : darkMode
                    ? 'bg-zinc-900/55 text-zinc-100 border-zinc-800/35 rounded-tl-none'
                    : 'bg-white/65 text-zinc-800 border-white/55 rounded-tl-none'
                }`}>
                  
                  {/* File Attachment Render */}
                  {msg.file && (
                    <div className={`p-2 rounded-xl mb-2 flex items-center gap-3 border ${
                      isMe 
                        ? 'bg-emerald-600 border-emerald-500 text-white' 
                        : (darkMode ? 'bg-zinc-900 border-zinc-800 text-zinc-200' : 'bg-slate-50 border-zinc-100 text-zinc-800')
                    }`}>
                      <FileText size={22} className="shrink-0" />
                      <div className="min-w-0">
                        <p className="font-bold text-[11px] truncate">{msg.file.name}</p>
                        <span className="text-[9px] opacity-75">{msg.file.size}</span>
                      </div>
                    </div>
                  )}

                  {/* Image Attachment Render */}
                  {msg.image && (
                    <img
                      src={msg.image}
                      alt="Attachment"
                      className="max-w-full h-auto rounded-xl max-h-48 mb-2 border border-black/5 object-cover"
                    />
                  )}

                  {/* Text Message body */}
                  {msg.message && <p className="whitespace-pre-wrap">{msg.message}</p>}
                </div>

                {/* Subtitle Timestamp & Ticks */}
                <div className="flex items-center gap-1 mt-1 text-[9px] font-bold text-zinc-400">
                  <span>{formatTimeStr(msg.timestamp)}</span>
                  {isMe && (
                    <span>
                      {msg.status === 'read' ? (
                        <CheckCheck size={11} className="text-brand-primary" />
                      ) : (
                        <Check size={11} />
                      )}
                    </span>
                  )}
                </div>

              </div>
            );
          })
        )}

        {/* Peer Typing status indicator */}
        {isTyping && (
          <div className="self-start flex flex-col items-start max-w-[60%]">
            <div className={`p-3 rounded-2xl rounded-tl-none text-[12px] flex items-center gap-1.5 ${
              darkMode ? 'bg-zinc-850 text-zinc-300' : 'bg-white text-zinc-500'
            }`}>
              <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
              <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3. ATTACHMENTS PREVIEW OVERLAYS */}
      {(selectedImage || selectedFile) && (
        <div className={`p-3.5 border-t border-b flex items-center justify-between transition-all duration-300 ${
          darkMode ? 'bg-zinc-900/35 border-zinc-850/35 text-white' : 'bg-white/35 border-white/35 text-zinc-800 shadow-sm'
        }`}>
          <div className="flex items-center gap-3 min-w-0">
            {selectedImage ? (
              <img src={selectedImage} alt="Selection preview" className="w-12 h-12 rounded-xl object-cover border" />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-brand-secondary/15 flex items-center justify-center text-brand-secondary">
                <FileText size={18} />
              </div>
            )}
            <div className="min-w-0">
              <p className="font-bold text-[11px] truncate">
                {selectedImage ? 'Image Selected' : selectedFile?.name}
              </p>
              <span className="text-[9px] text-zinc-400 block mt-0.5">Ready to transmit</span>
            </div>
          </div>
          <button
            onClick={() => { setSelectedImage(null); setSelectedFile(null); }}
            className="p-1 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-500 hover:text-zinc-800"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* 4. QUICK EMOJI SELECTION BAR */}
      {showEmojiTray && (
        <div className={`px-4 py-2 flex items-center justify-between border-t gap-1.5 transition-all duration-300 overflow-x-auto ${
          darkMode ? 'bg-zinc-900/30 border-zinc-850/30' : 'bg-white/30 border-white/30'
        }`}>
          {popularEmojis.map((emoji) => (
            <button
              key={emoji}
              onClick={() => handleEmojiClick(emoji)}
              className="text-lg hover:scale-125 transition-transform shrink-0 p-1 cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* 5. BOTTOM TEXT MESSAGE INPUT BAR */}
      <form
        onSubmit={handleSendMessage}
        className={`p-3.5 flex items-center gap-2 z-20 transition-all duration-300 border-t ${
          darkMode ? 'bg-zinc-900/40 border-zinc-850/40' : 'bg-white/40 border-white/40'
        }`}
      >
        {/* Invisible Inputs */}
        <input type="file" ref={imageInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
        <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="*" className="hidden" />

        {/* Emoji Button */}
        <button
          type="button"
          onClick={() => setShowEmojiTray(!showEmojiTray)}
          className={`p-2 rounded-xl transition-colors ${
            showEmojiTray 
              ? 'text-brand-primary bg-brand-primary/10' 
              : (darkMode ? 'text-zinc-400 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
          }`}
        >
          <Smile size={18} />
        </button>

        {/* Attachment Button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className={`p-2 rounded-xl transition-colors ${
            darkMode ? 'text-zinc-400 hover:text-white' : 'text-zinc-500 hover:text-zinc-900'
          }`}
        >
          <Paperclip size={18} />
        </button>

        {/* Camera Button */}
        <button
          type="button"
          onClick={() => imageInputRef.current?.click()}
          className={`p-2 rounded-xl transition-colors ${
            darkMode ? 'text-zinc-400 hover:text-white' : 'text-zinc-500 hover:text-zinc-900'
          }`}
        >
          <Camera size={18} />
        </button>

        {/* Text Input field */}
        <input
          type="text"
          placeholder="Type your message here..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className={`flex-1 h-10 px-3.5 rounded-xl text-xs font-semibold focus:outline-none transition-all ${
            darkMode
              ? 'bg-zinc-900/30 focus:bg-zinc-900/50 border border-zinc-800/40 text-white placeholder-zinc-500'
              : 'bg-white/50 focus:bg-white/70 border border-white/55 text-zinc-800 placeholder-zinc-400'
          }`}
        />

        {/* Send Button */}
        <button
          type="submit"
          className="w-10 h-10 rounded-xl bg-brand-primary hover:bg-emerald-600 transition-colors flex items-center justify-center text-white shrink-0 active:scale-95 cursor-pointer shadow-md shadow-emerald-500/10"
        >
          <Send size={16} />
        </button>
      </form>

    </div>
  );
}
