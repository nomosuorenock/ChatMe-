/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import { motion } from 'motion/react';
import { MessageSquareDot } from 'lucide-react';

interface SplashViewProps {
  onFinish: () => void;
  darkMode: boolean;
}

export default function SplashView({ onFinish, darkMode }: SplashViewProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className={`w-full h-full flex flex-col justify-between py-12 px-8 select-none transition-all duration-300 ${
      darkMode ? 'bg-zinc-950/40 backdrop-blur-lg text-white' : 'bg-white/40 backdrop-blur-lg text-zinc-900'
    }`}>
      {/* Invisible placeholder for layout spacing */}
      <div className="h-10" />

      {/* Center Brand Identity */}
      <div className="flex flex-col items-center">
        {/* Animated Logo */}
        <motion.div
          initial={{ scale: 0.3, rotate: -30, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 120, damping: 15 }}
          className="relative w-24 h-24 mb-6"
        >
          <img src="/assets/logo.png" alt="ChatMe Logo" className="w-full h-full object-contain" />
          
          {/* Accent Glow rings */}
          <motion.div
            animate={{ scale: [1, 1.3, 1], opacity: [0.4, 0, 0.4] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -inset-2 rounded-[32px] border-2 border-brand-primary/20 pointer-events-none"
          />
        </motion.div>

        {/* Brand Name */}
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-4xl font-extrabold font-display tracking-tight text-center"
        >
          Chat<span className="text-brand-primary">Me</span>
        </motion.h1>

        {/* Slogan */}
        <motion.p
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 0.7 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-sm text-center mt-2.5 font-medium tracking-wide text-zinc-500"
        >
          Connecting people instantly
        </motion.p>
      </div>

      {/* Footer Loading bar & credits */}
      <div className="flex flex-col items-center gap-4">
        {/* Sleek Line Loading Indicator */}
        <div className="w-40 h-1 bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ left: '-100%' }}
            animate={{ left: '100%' }}
            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
            className="relative w-full h-full bg-gradient-to-r from-brand-primary to-brand-secondary rounded-full"
          />
        </div>

        {/* Text Loader */}
        <span className="text-[11px] font-mono tracking-widest text-zinc-400 font-semibold uppercase">
          Initializing App
        </span>
      </div>
    </div>
  );
}
