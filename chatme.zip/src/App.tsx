/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { MessageSquare, Users, Phone, User as UserIcon, Circle, Bot } from 'lucide-react';
import StatusTab from './components/StatusTab';
import ChatBotTab from './components/ChatBotTab';
import { motion, AnimatePresence } from 'motion/react';

// Data types and local storage database
import { User, ScreenType, HomeTab, ActiveCallState, AppSettings } from './types';
import { ChatMeDB } from './lib/database';

// Modular UI Components
import DeviceFrame from './components/DeviceFrame';
import SplashView from './components/SplashView';
import AuthViews from './components/AuthViews';
import CallOverlay from './components/CallOverlay';
import ChatsTab from './components/ChatsTab';
import ContactsTab from './components/ContactsTab';
import CallsTab from './components/CallsTab';
import ProfileTab from './components/ProfileTab';
import SettingsView from './components/SettingsView';
import ChatRoomView from './components/ChatRoomView';

export default function App() {
  // 1. Core State Managers
  const [activeScreen, setActiveScreen] = useState<ScreenType>('splash');
  const [activeTab, setActiveTab] = useState<HomeTab>('chats');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeChatContact, setActiveChatContact] = useState<User | null>(null);
  const [activeCall, setActiveCall] = useState<ActiveCallState | null>(null);
  
  const [settings, setSettings] = useState<AppSettings>({
    darkMode: false,
    notificationsEnabled: true,
    privacyLocked: false,
  });

  // 2. Initialize Database on Mount
  useEffect(() => {
    ChatMeDB.initialize();

    // Check for cached dark mode preference
    const cachedSettings = ChatMeDB.getStorageItem<AppSettings | null>('app_settings', null);
    if (cachedSettings) {
      setSettings(cachedSettings);
    }

    // Check for active session
    const cachedUser = ChatMeDB.getActiveUser();
    if (cachedUser) {
      setCurrentUser(cachedUser);
    }
  }, []);

  // Sync settings helper
  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    ChatMeDB.setStorageItem('app_settings', newSettings);
  };

  // 3. Navigation Orchestration callbacks
  const handleSplashFinish = () => {
    const cachedUser = ChatMeDB.getActiveUser();
    if (cachedUser) {
      setCurrentUser(cachedUser);
      setActiveScreen('home');
    } else {
      setActiveScreen('signin');
    }
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    ChatMeDB.setActiveUser(user);
    setActiveScreen('home');
  };

  const handleLogout = () => {
    ChatMeDB.setActiveUser(null);
    setCurrentUser(null);
    setActiveScreen('signin');
    setActiveTab('chats');
    setActiveChatContact(null);
  };

  const handleOpenChat = (contact: User) => {
    setActiveChatContact(contact);
    setActiveScreen('chat');
  };

  // 4. Voice / Video call callbacks
  const handleInitiateCall = (contact: User, type: 'voice' | 'video') => {
    setActiveCall({
      contact,
      type,
      status: 'dialing',
      durationSeconds: 0,
    });
  };

  const handleEndCall = (durationStr: string) => {
    if (activeCall && currentUser) {
      // Save Call Record to the Local Database
      ChatMeDB.addCallRecord({
        caller_id: currentUser.id,
        receiver_id: activeCall.contact.id,
        type: activeCall.type,
        duration: durationStr,
        status: durationStr === 'Missed' ? 'missed' : 'outgoing',
      });
    }
    // Close overlay
    setActiveCall(null);
  };

  // Render helper for tab panels inside Home
  const renderHomeTabContent = () => {
    if (!currentUser) return null;

    switch (activeTab) {
      case 'chats':
        return (
          <ChatsTab
            currentUser={currentUser}
            onOpenChat={handleOpenChat}
            onOpenAI={() => setActiveTab('chatbot')}
            darkMode={settings.darkMode}
          />
        );
      case 'contacts':
        return (
          <ContactsTab
            currentUser={currentUser}
            onSelectContact={handleOpenChat}
            darkMode={settings.darkMode}
          />
        );
      case 'status':
        return (
          <StatusTab
            currentUser={currentUser}
            darkMode={settings.darkMode}
          />
        );
      case 'calls':
        return (
          <CallsTab
            currentUser={currentUser}
            onInitiateCall={handleInitiateCall}
            darkMode={settings.darkMode}
          />
        );
      case 'chatbot':
        return (
          <ChatBotTab
            darkMode={settings.darkMode}
          />
        );
      case 'profile':
        return (
          <ProfileTab
            currentUser={currentUser}
            onUpdateUser={(updated) => setCurrentUser(updated)}
            onNavigateToSettings={() => setActiveScreen('settings')}
            onLogout={handleLogout}
            darkMode={settings.darkMode}
          />
        );
      default:
        return null;
    }
  };

  return (
    <DeviceFrame darkMode={settings.darkMode}>
      
      {/* 1. SPLASH SCREEN (Self routing on finish) */}
      {activeScreen === 'splash' && (
        <SplashView onFinish={handleSplashFinish} darkMode={settings.darkMode} />
      )}

      {/* 2. AUTH SCREENS (Sign In, Create Account, Reset Password) */}
      {(activeScreen === 'signin' || activeScreen === 'signup' || activeScreen === 'resetpassword') && (
        <AuthViews
          currentScreen={activeScreen}
          onNavigate={(scr) => {
            if (scr === 'home') setActiveScreen('home');
            else setActiveScreen(scr);
          }}
          onLoginSuccess={handleLoginSuccess}
          darkMode={settings.darkMode}
        />
      )}

      {/* 3. HOME TAB VIEWS PANEL (Chats, Contacts, Calls, Profile) */}
      {activeScreen === 'home' && currentUser && (
        <div className={`w-full h-full flex flex-col justify-between transition-all duration-300 ${
          settings.darkMode ? 'bg-zinc-950/45 backdrop-blur-lg text-white' : 'bg-white/45 backdrop-blur-lg text-zinc-900'
        }`}>
          {/* Active Tab viewport */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {renderHomeTabContent()}
          </div>

          {/* Bottom Tab Navigation Bar */}
          <div className={`h-[68px] border-t px-6 flex items-center justify-between shrink-0 select-none transition-all duration-300 ${
            settings.darkMode ? 'bg-zinc-900/40 border-zinc-800/40' : 'bg-white/40 border-white/40'
          }`}>
            
            {/* Chats Tab */}
            <button
              onClick={() => setActiveTab('chats')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'chats'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <MessageSquare size={18} />
              <span className="text-[10px] font-bold tracking-wide">Chats</span>
            </button>

            {/* Status Tab */}
            <button
              onClick={() => setActiveTab('status')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'status'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <Circle size={18} />
              <span className="text-[10px] font-bold tracking-wide">Status</span>
            </button>

            {/* Contacts Tab */}
            <button
              onClick={() => setActiveTab('contacts')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'contacts'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <Users size={18} />
              <span className="text-[10px] font-bold tracking-wide">Contacts</span>
            </button>

            {/* Calls Tab */}
            <button
              onClick={() => setActiveTab('calls')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'calls'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <Phone size={18} />
              <span className="text-[10px] font-bold tracking-wide">Calls</span>
            </button>

            {/* Chatbot Tab */}
            <button
              onClick={() => setActiveTab('chatbot')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'chatbot'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <Bot size={18} />
              <span className="text-[10px] font-bold tracking-wide">AI</span>
            </button>

            {/* Profile Tab */}
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                activeTab === 'profile'
                  ? 'text-brand-primary'
                  : 'text-zinc-400 hover:text-zinc-500 dark:hover:text-zinc-300'
              }`}
            >
              <UserIcon size={18} />
              <span className="text-[10px] font-bold tracking-wide">Profile</span>
            </button>

          </div>
        </div>
      )}

      {/* 4. CHAT ROOM VIEW (Focused messaging thread) */}
      {activeScreen === 'chat' && currentUser && activeChatContact && (
        <ChatRoomView
          currentUser={currentUser}
          contact={activeChatContact}
          onBack={() => setActiveScreen('home')}
          onInitiateCall={handleInitiateCall}
          darkMode={settings.darkMode}
        />
      )}

      {/* 5. APP SETTINGS SCREEN (Modifying preferences, password changes) */}
      {activeScreen === 'settings' && currentUser && (
        <SettingsView
          currentUser={currentUser}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onBack={() => setActiveScreen('home')}
          onLogout={handleLogout}
          darkMode={settings.darkMode}
        />
      )}

      {/* ======================================================== */}
      {/* 6. CALLS OVERLAY SIMULATION (Pulsing, Web Audio sounds, live camera feeds) */}
      {/* ======================================================== */}
      <AnimatePresence>
        {activeCall && currentUser && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ type: 'spring', duration: 0.55 }}
            className="absolute inset-0 z-50 overflow-hidden"
          >
            <CallOverlay
              callState={activeCall}
              onEndCall={handleEndCall}
              currentUser={currentUser}
              darkMode={settings.darkMode}
            />
          </motion.div>
        )}
      </AnimatePresence>

    </DeviceFrame>
  );
}
