/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, ChatMessage, CallRecord, GroupChat } from '../types';

// Pre-seeded avatars and gradients for premium UI
export const PRE_SEEDED_USERS: User[] = [
  {
    id: 'user_sarah',
    fullname: 'Sarah Jenkins',
    email: 'sarah@chatme.app',
    bio: 'Coffee & Code ☕ | React & TypeScript Enthusiast',
    phone: '+1 (555) 019-2834',
    photo: 'gradient:from-emerald-400:to-teal-600',
    created_at: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
    isOnline: true,
  },
  {
    id: 'user_alex',
    fullname: 'Alex Rivera',
    email: 'alex@chatme.app',
    bio: 'Design is thinking made visual 🎨 | UX/UI Designer',
    phone: '+1 (555) 014-9823',
    photo: 'gradient:from-blue-400:to-indigo-600',
    created_at: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
    isOnline: true,
  },
  {
    id: 'user_emily',
    fullname: 'Emily Chen',
    email: 'emily@chatme.app',
    bio: 'On a journey to explore the world 🌍 | Photographer',
    phone: '+1 (555) 018-8832',
    photo: 'gradient:from-pink-400:to-rose-600',
    created_at: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString(),
    isOnline: false,
  },
  {
    id: 'user_david',
    fullname: 'David Miller',
    email: 'david@chatme.app',
    bio: 'Let\'s build something epic! 💻 | Full-Stack Engineer',
    phone: '+1 (555) 011-2345',
    photo: 'gradient:from-amber-400:to-orange-600',
    created_at: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
    isOnline: true,
  },
  {
    id: 'user_support',
    fullname: 'Support Bot',
    email: 'support@chatme.app',
    bio: 'Official ChatMe Assistant 🤖 | Here to help',
    phone: '+1 (500) 242-8631',
    photo: 'gradient:from-violet-500:to-purple-700',
    created_at: new Date().toISOString(),
    isOnline: true,
  },
];

// Helper to get beautiful custom initials or custom file avatars
export function getAvatarStyle(photo: string): { background: string; text: string } {
  if (photo && photo.startsWith('gradient:')) {
    const parts = photo.split(':');
    const fromColor = parts[1]?.replace('from-', '') || 'emerald-500';
    const toColor = parts[2]?.replace('to-', '') || 'teal-600';

    // Map tailwind color tags to actual CSS values for fallback inline styling
    const colorMap: Record<string, string> = {
      'emerald-400': '#34D399', 'emerald-500': '#10B981', 'teal-600': '#0D9488',
      'blue-400': '#60A5FA', 'indigo-600': '#4F46E5',
      'pink-400': '#F472B6', 'rose-600': '#E11D48',
      'amber-400': '#F59E0B', 'orange-600': '#EA580C',
      'violet-500': '#8B5CF6', 'purple-700': '#6D28D9',
    };

    const fromVal = colorMap[fromColor] || '#22C55E';
    const toVal = colorMap[toColor] || '#15803D';

    return {
      background: `linear-gradient(135deg, ${fromVal}, ${toVal})`,
      text: '#FFFFFF',
    };
  }

  // If base64 uploaded image
  return {
    background: `url(${photo}) center/cover no-repeat`,
    text: 'transparent',
  };
}

export function getInitials(fullname: string): string {
  if (!fullname) return 'CM';
  const parts = fullname.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return fullname.slice(0, 2).toUpperCase();
}

// Initial Chats Seeds
const INITIAL_CHATS: ChatMessage[] = [
  {
    id: 'msg_seed_1',
    sender_id: 'user_sarah',
    receiver_id: 'current_user_default', // will be replaced or mapped dynamically
    message: 'Hey there! Are you coming to the developer meetup tomorrow afternoon? ☕ We are reviewing some interesting TypeScript 5.8 features!',
    timestamp: new Date(Date.now() - 3600 * 1000 * 4).toISOString(), // 4 hours ago
    status: 'read',
  },
  {
    id: 'msg_seed_2',
    sender_id: 'user_alex',
    receiver_id: 'current_user_default',
    message: 'Just uploaded the high-fidelity mobile designs for ChatMe in the Figma workspace. Let me know what you think about the green and blue accents! 🎨',
    timestamp: new Date(Date.now() - 3600 * 1000 * 8).toISOString(), // 8 hours ago
    status: 'read',
  },
  {
    id: 'msg_seed_3',
    sender_id: 'user_emily',
    receiver_id: 'current_user_default',
    message: 'Look at this gorgeous sunset shot I took yesterday during my hike! 🌅 Can\'t wait to share the rest of the album once I finish editing them.',
    image: 'https://images.unsplash.com/photo-1472214222541-d510753a4907?auto=format&fit=crop&q=80&w=400',
    timestamp: new Date(Date.now() - 3600 * 1000 * 24).toISOString(), // Yesterday
    status: 'read',
  },
  {
    id: 'msg_seed_4',
    sender_id: 'user_david',
    receiver_id: 'current_user_default',
    message: 'Hey buddy, did you check the latency optimizations on the chat endpoint? It is looking super responsive now!',
    timestamp: new Date(Date.now() - 3600 * 1000 * 48).toISOString(), // 2 days ago
    status: 'read',
  },
  {
    id: 'msg_seed_5',
    sender_id: 'user_support',
    receiver_id: 'current_user_default',
    message: 'Welcome to ChatMe! 🚀 I can help you test out features like calling, dark mode, attachments, and messaging. Just text me anything!',
    timestamp: new Date(Date.now() - 3600 * 1000 * 120).toISOString(), // 5 days ago
    status: 'read',
  },
];

// Initial Call History
const INITIAL_CALLS: CallRecord[] = [
  {
    id: 'call_seed_1',
    caller_id: 'current_user_default',
    receiver_id: 'user_david',
    type: 'voice',
    duration: '03:42',
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15 mins ago
    status: 'outgoing',
  },
  {
    id: 'call_seed_2',
    caller_id: 'user_sarah',
    receiver_id: 'current_user_default',
    type: 'video',
    duration: '12:15',
    timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(), // 2 hours ago
    status: 'incoming',
  },
  {
    id: 'call_seed_3',
    caller_id: 'user_alex',
    receiver_id: 'current_user_default',
    type: 'voice',
    duration: 'Missed',
    timestamp: new Date(Date.now() - 24 * 3600 * 1000).toISOString(), // 1 day ago
    status: 'missed',
  },
];

export class ChatMeDB {
  static getStorageItem<T>(key: string, defaultValue: T): T {
    try {
      const val = localStorage.getItem(`chatme_${key}`);
      return val ? JSON.parse(val) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  static setStorageItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(`chatme_${key}`, JSON.stringify(value));
    } catch (e) {
      console.error('Failed to store chatme data:', e);
    }
  }

  // Initialize DB with seeds if empty
  static initialize(): void {
    // 1. Seed Registered Users (for simulated logins/signups)
    const existingUsers = this.getStorageItem<User[]>('users', []);
    if (existingUsers.length === 0) {
      // Pre-register pre-seeded accounts so users can log in with them if they want
      // and keep a master list
      const seededAccounts: User[] = [
        ...PRE_SEEDED_USERS,
        // Add a default test account for fast onboarding
        {
          id: 'user_demo',
          fullname: 'Alex Demo',
          email: 'demo@chatme.app',
          password: 'password123',
          photo: 'gradient:from-blue-400:to-indigo-600',
          bio: 'Testing out the amazing ChatMe app! 🚀',
          phone: '+1 (555) 123-4567',
          created_at: new Date().toISOString(),
        }
      ];
      this.setStorageItem('users', seededAccounts);
    }

    // 2. Active User Session
    const activeUser = localStorage.getItem('chatme_active_user');
    if (!activeUser) {
      // Do not force log in, show splash -> sign in screen
    }

    // 3. Seed Conversations (Chats)
    const existingChats = this.getStorageItem<ChatMessage[]>('chats', []);
    if (existingChats.length === 0) {
      this.setStorageItem('chats', INITIAL_CHATS);
    }

    // 4. Seed Call History
    const existingCalls = this.getStorageItem<CallRecord[]>('calls', []);
    if (existingCalls.length === 0) {
      this.setStorageItem('calls', INITIAL_CALLS);
    }

    // 5. Seed Contacts
    const contacts = this.getStorageItem<string[]>('contacts', []);
    if (contacts.length === 0) {
      // Default contacts are all pre-seeded users
      const defaultContacts = PRE_SEEDED_USERS.map((u) => u.id);
      this.setStorageItem('contacts', defaultContacts);
    }
  }

  static getActiveUser(): User | null {
    return this.getStorageItem<User | null>('active_user', null);
  }

  static setActiveUser(user: User | null): void {
    this.setStorageItem('active_user', user);
  }

  static getGroupChatsForUser(userId: string): GroupChat[] {
    const allGroups = this.getStorageItem<GroupChat[]>('groups', []);
    return allGroups.filter((g) => g.members.includes(userId));
  }

  static createGroupChat(name: string, members: string[]): GroupChat {
    const allGroups = this.getStorageItem<GroupChat[]>('groups', []);
    const newGroup: GroupChat = {
      id: `group_${Math.random().toString(36).substr(2, 9)}`,
      name,
      members,
      created_at: new Date().toISOString(),
    };
    allGroups.push(newGroup);
    this.setStorageItem('groups', allGroups);
    return newGroup;
  }

  static getUsers(): User[] {
    return this.getStorageItem<User[]>('users', PRE_SEEDED_USERS);
  }

  static registerUser(user: Omit<User, 'id' | 'created_at'> & { password?: string }): User {
    const users = this.getUsers();
    const newUser: User = {
      ...user,
      id: `user_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      isOnline: true,
    };
    users.push(newUser);
    this.setStorageItem('users', users);
    return newUser;
  }

  static updateUser(updatedUser: User): void {
    const users = this.getUsers();
    const idx = users.findIndex((u) => u.id === updatedUser.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      this.setStorageItem('users', users);
    }

    // If active user is being updated, save to session
    const active = this.getActiveUser();
    if (active && active.id === updatedUser.id) {
      this.setActiveUser(updatedUser);
    }
  }

  static getChatsForUser(userId: string): ChatMessage[] {
    const allChats = this.getStorageItem<ChatMessage[]>('chats', []);
    // Map seeded messages with "current_user_default" to this user's ID
    return allChats.map((msg) => {
      let sender = msg.sender_id;
      let receiver = msg.receiver_id;
      if (sender === 'current_user_default') sender = userId;
      if (receiver === 'current_user_default') receiver = userId;
      return { ...msg, sender_id: sender, receiver_id: receiver };
    });
  }

  static addChatMessage(message: Omit<ChatMessage, 'id' | 'timestamp' | 'status'>): ChatMessage {
    const allChats = this.getStorageItem<ChatMessage[]>('chats', []);
    const newMessage: ChatMessage = {
      ...message,
      id: `msg_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      status: 'sent',
    };
    allChats.push(newMessage);
    this.setStorageItem('chats', allChats);
    return newMessage;
  }

  static markChatsAsRead(senderId: string, receiverId: string): void {
    const allChats = this.getStorageItem<ChatMessage[]>('chats', []);
    let changed = false;
    const updated = allChats.map((msg) => {
      // Seeds map "current_user_default" dynamically, so we handle both raw check and actual user check
      const matchSender = msg.sender_id === senderId || (msg.sender_id === 'current_user_default' && senderId === receiverId);
      const matchReceiver = msg.receiver_id === receiverId || (msg.receiver_id === 'current_user_default' && receiverId === senderId);

      if (matchSender && msg.status !== 'read') {
        changed = true;
        return { ...msg, status: 'read' as const };
      }
      return msg;
    });
    if (changed) {
      this.setStorageItem('chats', updated);
    }
  }

  static getCalls(userId: string): CallRecord[] {
    const allCalls = this.getStorageItem<CallRecord[]>('calls', []);
    return allCalls.map((call) => {
      let caller = call.caller_id;
      let receiver = call.receiver_id;
      if (caller === 'current_user_default') caller = userId;
      if (receiver === 'current_user_default') receiver = userId;
      return { ...call, caller_id: caller, receiver_id: receiver };
    });
  }

  static addCallRecord(call: Omit<CallRecord, 'id' | 'timestamp'>): CallRecord {
    const allCalls = this.getStorageItem<CallRecord[]>('calls', []);
    const newCall: CallRecord = {
      ...call,
      id: `call_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    allCalls.push(newCall);
    this.setStorageItem('calls', allCalls);
    return newCall;
  }

  static clearDatabase(): void {
    localStorage.removeItem('chatme_users');
    localStorage.removeItem('chatme_chats');
    localStorage.removeItem('chatme_calls');
    localStorage.removeItem('chatme_contacts');
    localStorage.removeItem('chatme_active_user');
    this.initialize();
  }

  // Core Smart Chat Simulator responses mapping to personalities
  static getSimulatedReply(contactId: string, userMessage: string): string {
    const msgLower = userMessage.toLowerCase();

    if (contactId === 'user_sarah') {
      if (msgLower.includes('meet') || msgLower.includes('tomorrow') || msgLower.includes('where')) {
        return 'The meetup is at 3 PM at the Coffee Lab downtown! ☕ I will bring my laptop so we can dive into the React 19 server actions together.';
      }
      if (msgLower.includes('react') || msgLower.includes('bug') || msgLower.includes('typescript')) {
        return 'TypeScript 5.8 has some amazing enhancements! Check out the return type inference improvements. Let me know if you want me to review your tsconfig!';
      }
      if (msgLower.includes('hello') || msgLower.includes('hey') || msgLower.includes('hi')) {
        return 'Hey! Just finished my double espresso and checking some PRs. What are you coding today? 💻';
      }
      return 'That sounds super interesting! Let me write some tests for it first, then let\'s discuss it over some hot espresso tomorrow! ☕✨';
    }

    if (contactId === 'user_alex') {
      if (msgLower.includes('design') || msgLower.includes('figma') || msgLower.includes('mockup') || msgLower.includes('color')) {
        return 'Yes! I used a clean vivid green (#22C55E) paired with a deep tech blue (#3B82F6) to build contrast. Let\'s keep 12px rounded corners on all device panels to preserve that premium tactile feel. 🎨';
      }
      if (msgLower.includes('hello') || msgLower.includes('hey') || msgLower.includes('hi')) {
        return 'Hey! I\'m currently restructuring the user journey mapping for the settings panel. How is the layout looking on your screen?';
      }
      return 'Great point! Let me update the spacing and padding values in the design system. I\'ll export the new SVG assets right away. 🎨📐';
    }

    if (contactId === 'user_emily') {
      if (msgLower.includes('photo') || msgLower.includes('sunset') || msgLower.includes('hike') || msgLower.includes('camera')) {
        return 'The sunset at Yosemite was magical! 🌅 I used a 50mm f/1.8 lens to get that gorgeous background compression and warm bokeh. I am setting up my portfolio tonight!';
      }
      if (msgLower.includes('hello') || msgLower.includes('hey') || msgLower.includes('hi')) {
        return 'Hi! Just got back from sorting my memory cards. I traveled so much this week! 📸 Where is your next vacation destination?';
      }
      return 'I completely agree! Nature has the absolute best color palettes. I\'ll send you some more high-resolution shots once they render! 🌲🗺️';
    }

    if (contactId === 'user_david') {
      if (msgLower.includes('latency') || msgLower.includes('speed') || msgLower.includes('optimize') || msgLower.includes('server')) {
        return 'Exactly! By batching updates in LocalStorage and pre-loading state in memoized hooks, we completely cut out the layout flickering! The rendering latency is basically 0ms now. 🚀';
      }
      if (msgLower.includes('hello') || msgLower.includes('hey') || msgLower.includes('hi')) {
        return 'Yo! Just finished a quick gym session and now refactoring some backend routes. What\'s cooking, my friend?';
      }
      return 'No worries! Send over the code snippet or repository link and I will troubleshoot the event loop for you. Let\'s build this thing fast! 💻🛠️';
    }

    if (contactId === 'user_support') {
      if (msgLower.includes('dark') || msgLower.includes('mode') || msgLower.includes('theme')) {
        return 'To toggle Dark Mode, go to the Profile tab 👤 (bottom right), click on Settings ⚙️, and toggle the Dark Mode option. The theme will instantly adapt to a premium eye-safe palette!';
      }
      if (msgLower.includes('call') || msgLower.includes('voice') || msgLower.includes('video')) {
        return 'You can simulate real-time calls! Click the voice call 📞 or video call 📹 buttons at the top right of any chat. It rings with audio synthesis, connects, and shows a real camera preview if you allow permissions!';
      }
      if (msgLower.includes('file') || msgLower.includes('image') || msgLower.includes('upload') || msgLower.includes('send')) {
        return 'You can send files or images inside chats! Click the Attachment 📎 or Camera 📷 buttons next to the text input. You can select any local image or document to upload and send it instantly!';
      }
      if (msgLower.includes('profile') || msgLower.includes('edit') || msgLower.includes('photo')) {
        return 'To edit your profile details, navigate to the Profile Tab, click "Edit Profile" and modify your full name, phone number, bio, or upload a brand-new profile picture! 👤✨';
      }
      return 'ChatMe is a highly functional mockup workspace! You can:\n• 💬 Chat with Sarah, Alex, Emily, and David\n• 📞 Make simulated Voice/Video calls with live webcam\n• 👤 Customize your profile details and avatar photo\n• ⚙️ Configure notification, dark mode, and privacy lock features\n\nWhat would you like assistance with?';
    }

    return 'That is awesome! Let\'s keep chatting and test out some more features of ChatMe! 💬🚀';
  }
}
